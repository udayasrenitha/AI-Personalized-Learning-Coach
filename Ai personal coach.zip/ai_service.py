"""
AI Service Layer for AI Personalized Learning Coach.
Handles Google Gemini API calls, prompt engineering, structured JSON extraction,
and intelligent graceful fallbacks for offline or unconfigured environments.
"""

import os
import re
import json
import logging
from typing import Dict, Any, List, Optional
from config import get_gemini_api_key

logger = logging.getLogger(__name__)

# Preferred Gemini model
DEFAULT_MODEL = "gemini-2.5-flash"

def extract_json_from_text(text: str) -> Optional[Any]:
    """
    Robustly extracts and parses JSON from LLM responses, handling markdown
    fences, leading/trailing prose, and minor formatting irregularities.
    """
    if not text:
        return None

    cleaned = text.strip()

    # 1. Strip markdown code fence if wrapped in ```json ... ``` or ``` ... ```
    match = re.search(r"```(?:json)?\s*([\s\S]*?)\s*```", cleaned)
    if match:
        cleaned = match.group(1).strip()

    # 2. Try direct JSON parse
    try:
        return json.loads(cleaned)
    except json.JSONDecodeError:
        pass

    # 3. Find outermost { ... } or [ ... ]
    first_brace = cleaned.find("{")
    first_bracket = cleaned.find("[")

    start_idx = -1
    is_object = False

    if first_brace != -1 and (first_bracket == -1 or first_brace < first_bracket):
        start_idx = first_brace
        is_object = True
    elif first_bracket != -1:
        start_idx = first_bracket
        is_object = False

    if start_idx != -1:
        end_char = "}" if is_object else "]"
        end_idx = cleaned.rfind(end_char)
        if end_idx > start_idx:
            sub = cleaned[start_idx : end_idx + 1]
            try:
                return json.loads(sub)
            except json.JSONDecodeError:
                # Remove trailing commas before closing braces/brackets
                sub_cleaned = re.sub(r",\s*([\]}])", r"\1", sub)
                try:
                    return json.loads(sub_cleaned)
                except json.JSONDecodeError:
                    pass

    return None

def call_gemini(prompt: str, system_instruction: Optional[str] = None) -> str:
    """
    Executes a prompt against Gemini API using the official google-genai library.
    Falls back gracefully if the key is missing or an error occurs.
    """
    api_key = get_gemini_api_key()
    if not api_key:
        raise ValueError("Google Gemini API key not found. Please provide an API key in settings or .env.")

    # Try modern google-genai SDK
    try:
        from google import genai
        from google.genai import types

        client = genai.Client(api_key=api_key)
        config = types.GenerateContentConfig(
            temperature=0.7,
            system_instruction=system_instruction
        ) if system_instruction else types.GenerateContentConfig(temperature=0.7)

        response = client.models.generate_content(
            model=DEFAULT_MODEL,
            contents=prompt,
            config=config
        )
        if response and response.text:
            return response.text
        raise ValueError("Empty response received from Gemini API.")

    except ImportError:
        # Fallback to legacy google.generativeai if installed
        try:
            import google.generativeai as legacy_genai
            legacy_genai.configure(api_key=api_key)
            model = legacy_genai.GenerativeModel("gemini-1.5-flash")
            response = model.generate_content(prompt)
            return response.text
        except Exception as e:
            raise RuntimeError(f"Gemini API execution failed: {str(e)}")
    except Exception as e:
        raise RuntimeError(f"Gemini API request failed: {str(e)}")

# ========================================================================= #
# 1. STUDY PLAN GENERATION
# ========================================================================= #

def generate_study_plan_ai(
    subject: str,
    goal: str,
    knowledge_level: str,
    target_days: int,
    daily_minutes: int,
    learning_style: str
) -> Dict[str, Any]:
    """
    Generates a personalized day-wise study plan using Gemini.
    Falls back to intelligent local generator if Gemini is unavailable.
    """
    api_key = get_gemini_api_key()

    if api_key:
        prompt = f"""
You are an expert AI Personalized Learning Coach and Curriculum Architect.
Generate a structured, day-wise, personalized study plan for a student with the following profile:

- Subject: {subject}
- Goal: {goal}
- Knowledge Level: {knowledge_level}
- Target Duration: {target_days} days
- Daily Available Study Time: {daily_minutes} minutes
- Preferred Learning Style: {learning_style}

Requirements:
1. Provide a plan with EXACTLY {target_days} days (from Day 1 to Day {target_days}).
2. Structure every single day with:
   - day_number: (integer 1 to {target_days})
   - topic_name: (clear, concise title)
   - objectives: (list of 2-3 specific learning outcomes)
   - key_concepts: (list of 3-5 core concepts or keywords)
   - estimated_minutes: (integer approx {daily_minutes})
   - practical_activities: (list of 2-3 hands-on tasks, mini-projects, or coding exercises tailored to {learning_style} style)
   - revision_tasks: (list of 2-3 quick self-check questions or recall drills)
3. Return ONLY a valid JSON object with NO surrounding markdown text, formatted as:
{{
  "subject": "{subject}",
  "goal": "{goal}",
  "knowledge_level": "{knowledge_level}",
  "target_days": {target_days},
  "daily_minutes": {daily_minutes},
  "learning_style": "{learning_style}",
  "summary": "2-3 sentences overview of this learning journey",
  "topics": [
    {{
      "day_number": 1,
      "topic_name": "...",
      "objectives": ["..."],
      "key_concepts": ["..."],
      "estimated_minutes": {daily_minutes},
      "practical_activities": ["..."],
      "revision_tasks": ["..."]
    }}
  ]
}}
"""
        try:
            raw_response = call_gemini(
                prompt=prompt,
                system_instruction="You are an elite educational technologist. Always output strictly valid JSON matching the user schema."
            )
            parsed = extract_json_from_text(raw_response)
            if parsed and isinstance(parsed, dict) and "topics" in parsed and len(parsed["topics"]) > 0:
                return parsed
        except Exception as e:
            logger.warning(f"Gemini API study plan generation failed ({e}), falling back to internal generator.")

    # Intelligent Fallback Plan Generator
    return generate_fallback_study_plan(
        subject=subject,
        goal=goal,
        knowledge_level=knowledge_level,
        target_days=target_days,
        daily_minutes=daily_minutes,
        learning_style=learning_style
    )

def generate_fallback_study_plan(
    subject: str,
    goal: str,
    knowledge_level: str,
    target_days: int,
    daily_minutes: int,
    learning_style: str
) -> Dict[str, Any]:
    """
    Constructs a high-quality educational study plan offline or as a fallback.
    If the subject is Python and target is 7 days, loads the standard example.
    Otherwise procedurally constructs curriculum milestones based on the subject and level.
    """
    # Check if we have exact match in sample_data
    sample_path = os.path.join(os.path.dirname(__file__), "sample_data", "example_learning_plan.json")
    if os.path.exists(sample_path) and "python" in subject.lower() and target_days == 7:
        try:
            with open(sample_path, "r", encoding="utf-8") as f:
                data = json.load(f)
                data["goal"] = goal
                data["knowledge_level"] = knowledge_level
                data["daily_minutes"] = daily_minutes
                data["learning_style"] = learning_style
                return data
        except Exception:
            pass

    # Generic procedural curriculum builder for any subject, duration, and level
    progression_templates = {
        "Beginner": [
            ("Core Fundamentals & Environment Setup", ["Syntax basics", "Tooling", "Core vocabulary"]),
            ("Foundational Syntax & Data Types", ["Primitive types", "Variables", "Basic operators"]),
            ("Control Flow & Decision Logic", ["Conditional statements", "Logical expressions", "Branching"]),
            ("Repetition, Loops & Iteration", ["Iteration patterns", "Counter loops", "Break/continue controls"]),
            ("Data Structures & Collections", ["Arrays/Lists", "Key-value mappings", "Indexing and traversal"]),
            ("Functions & Code Modularity", ["Function definitions", "Parameters and return types", "Scope"]),
            ("Practical Mini-Project & Diagnostic Review", ["Integrated coding exercise", "Debugging drills", "Core review"]),
            ("Error Handling & Debugging", ["Exceptions", "Defensive checks", "Logging/printing bugs"]),
            ("Standard Modules & Libraries", ["Built-in utilities", "Importing packages", "File operations"]),
            ("Capstone Project & Review", ["End-to-end implementation", "Best practices review", "Self-assessment"])
        ],
        "Intermediate": [
            ("Architecture Overview & Deep Dive", ["Memory model", "Internal mechanisms", "Design idioms"]),
            ("Object-Oriented & Modular Design", ["Classes", "Inheritance", "Polymorphism", "Encapsulation"]),
            ("Data Structures & Algorithmic Efficiency", ["Time complexity", "Memory trade-offs", "Optimization"]),
            ("Asynchronous & Concurrency Patterns", ["Event loops", "Async/await", "Threading/multiprocessing"]),
            ("API Integration & Data Pipelines", ["REST endpoints", "JSON transformation", "Error retry logic"]),
            ("Testing & Test-Driven Development", ["Unit testing", "Mocking", "Coverage analysis"]),
            ("Mid-Course Integration Project", ["Architectural refactoring", "Robust module structure"]),
            ("Database Integration & Persistence", ["Relational queries", "ORM patterns", "Data integrity"]),
            ("Performance Profiling & Optimization", ["Profiling bottlenecks", "Memory optimization", "Caching"]),
            ("Comprehensive Production-Ready Capstone", ["System design", "Deployment preparation", "Final review"])
        ],
        "Advanced": [
            ("System Internals & Execution Model", ["Under-the-hood engine", "Memory management", "Bytecode/compilation"]),
            ("Advanced Design Patterns & Architecture", ["Creational & structural patterns", "Domain-driven design"]),
            ("High-Throughput Concurrency & Networking", ["Low-level sockets", "Non-blocking IO", "Event streaming"]),
            ("Metaprogramming & Introspection", ["Decorators", "Reflection", "Dynamic code execution"]),
            ("Scalable State Management & Caching", ["Distributed caches", "Consistency models", "Invalidation"]),
            ("Security Auditing & Hardening", ["Sanitization", "Threat modeling", "Secure coding standards"]),
            ("Benchmark Analysis & Micro-Optimizations", ["JIT/profiler hooks", "Zero-copy operations", "Hot-path tuning"]),
            ("Production Architecture & Microservices", ["Resilience patterns", "Observability", "Circuit breakers"]),
            ("Comprehensive Enterprise Capstone", ["Full distributed system module", "Fault-tolerant architecture"]),
            ("Mastery Defense & Long-Term Roadmap", ["Architecture review", "Technical writing", "Advanced milestones"])
        ]
    }

    templates = progression_templates.get(knowledge_level, progression_templates["Beginner"])
    topics = []

    for day in range(1, target_days + 1):
        idx = (day - 1) % len(templates)
        base_name, concepts = templates[idx]
        topic_title = f"{subject}: {base_name}" if day <= len(templates) else f"{subject}: {base_name} (Part {day // len(templates) + 1})"

        topics.append({
            "day_number": day,
            "topic_name": topic_title,
            "objectives": [
                f"Master core principles of {base_name.lower()} in {subject}",
                f"Apply knowledge to fulfill the objective: {goal}",
                f"Implement clean, tested patterns according to {knowledge_level} standards"
            ],
            "key_concepts": [f"{subject} {c}" for c in concepts],
            "estimated_minutes": daily_minutes,
            "practical_activities": [
                f"Build a {learning_style.lower()}-focused hands-on exercise exploring {concepts[0]}",
                f"Implement a practical mini-challenge addressing {goal}"
            ],
            "revision_tasks": [
                f"Summarize the key takeaways of {concepts[0]} in your own words",
                f"Write 2 test questions to self-check your understanding of {base_name}"
            ]
        })

    return {
        "subject": subject,
        "goal": goal,
        "knowledge_level": knowledge_level,
        "target_days": target_days,
        "daily_minutes": daily_minutes,
        "learning_style": learning_style,
        "summary": f"A targeted {target_days}-day {knowledge_level} study journey for {subject}, designed to achieve your goal '{goal}' through {learning_style}-oriented daily sessions of {daily_minutes} minutes.",
        "topics": topics
    }

# ========================================================================= #
# 2. PRACTICE QUIZ GENERATION
# ========================================================================= #

def generate_quiz_ai(
    topic_name: str,
    subject: str,
    knowledge_level: str = "Beginner",
    learning_style: str = "Practice"
) -> List[Dict[str, Any]]:
    """
    Generates exactly 5 multiple choice questions for the given topic and subject.
    Validates the structure and falls back to offline generator on failure.
    """
    api_key = get_gemini_api_key()

    if api_key:
        prompt = f"""
You are an expert assessment designer for computer science and technical subjects.
Create a targeted 5-question multiple choice quiz for the following topic:

- Subject: {subject}
- Topic: {topic_name}
- Knowledge Level: {knowledge_level}
- Learning Style: {learning_style}

Requirements:
1. Provide EXACTLY 5 high-quality, practical multiple choice questions.
2. For each question, provide:
   - question: (clear question text, code snippet if relevant)
   - options: an object with exactly 4 keys: "A", "B", "C", "D"
   - correct_option: one of "A", "B", "C", or "D"
   - explanation: (thorough, student-friendly explanation of why the correct option is right and others are incorrect)
   - difficulty: "Beginner", "Medium", or "Hard"
3. Return ONLY a valid JSON array of 5 objects, with NO surrounding markdown prose:
[
  {{
    "question": "What is ...?",
    "options": {{
      "A": "Option 1",
      "B": "Option 2",
      "C": "Option 3",
      "D": "Option 4"
    }},
    "correct_option": "A",
    "explanation": "Option A is correct because...",
    "difficulty": "Medium"
  }}
]
"""
        try:
            raw_response = call_gemini(
                prompt=prompt,
                system_instruction="You are an expert technical evaluator. Output only valid JSON array of 5 quiz objects."
            )
            parsed = extract_json_from_text(raw_response)
            if parsed and isinstance(parsed, list) and len(parsed) >= 5:
                # Validate schema of each question
                validated = []
                for item in parsed[:5]:
                    if "question" in item and "options" in item and "correct_option" in item:
                        opts = item["options"]
                        if isinstance(opts, dict) and all(k in opts for k in ["A", "B", "C", "D"]):
                            validated.append({
                                "question": str(item["question"]),
                                "options": {
                                    "A": str(opts["A"]),
                                    "B": str(opts["B"]),
                                    "C": str(opts["C"]),
                                    "D": str(opts["D"])
                                },
                                "correct_option": str(item["correct_option"]).strip().upper()[:1],
                                "explanation": str(item.get("explanation", "Correct choice based on fundamentals.")),
                                "difficulty": str(item.get("difficulty", "Medium"))
                            })
                if len(validated) == 5:
                    return validated
        except Exception as e:
            logger.warning(f"Gemini API quiz generation failed ({e}), using fallback generator.")

    # High quality fallback quiz generator
    return generate_fallback_quiz(topic_name, subject, knowledge_level)

def generate_fallback_quiz(topic_name: str, subject: str, knowledge_level: str) -> List[Dict[str, Any]]:
    """
    Generates 5 realistic, domain-specific quiz questions when Gemini is unavailable.
    Includes rich questions for common subjects like Python, Loops, Functions, Variables, etc.
    """
    topic_lower = topic_name.lower()

    if "variable" in topic_lower or "data type" in topic_lower:
        return [
            {
                "question": "Which of the following is a valid variable name in Python?",
                "options": {
                    "A": "2my_var",
                    "B": "my-var",
                    "C": "_student_score",
                    "D": "class"
                },
                "correct_option": "C",
                "explanation": "Variable names in Python can start with an underscore or letter, but cannot start with digits, contain hyphens, or use reserved keywords like 'class'.",
                "difficulty": "Beginner"
            },
            {
                "question": "What is the output of type(3 / 2) in Python 3?",
                "options": {
                    "A": "<class 'int'>",
                    "B": "<class 'float'>",
                    "C": "<class 'double'>",
                    "D": "<class 'number'>"
                },
                "correct_option": "B",
                "explanation": "In Python 3, standard division '/' always produces a float (1.5 in this case), even when dividing two integers.",
                "difficulty": "Beginner"
            },
            {
                "question": "Which statement correctly converts the string '100' to an integer?",
                "options": {
                    "A": "to_int('100')",
                    "B": "int('100')",
                    "C": "Integer.parseInt('100')",
                    "D": "'100'.asInt()"
                },
                "correct_option": "B",
                "explanation": "int() is Python's built-in type conversion function to cast valid string literals to integer values.",
                "difficulty": "Beginner"
            },
            {
                "question": "What will be printed by: name = 'Alice'; print(f'Hello, {name.upper()}')?",
                "options": {
                    "A": "Hello, name.upper()",
                    "B": "Hello, {Alice}",
                    "C": "Hello, ALICE",
                    "D": "SyntaxError"
                },
                "correct_option": "C",
                "explanation": "Formatted f-strings evaluate expressions inside curly braces at runtime; name.upper() transforms 'Alice' to uppercase.",
                "difficulty": "Medium"
            },
            {
                "question": "What is the boolean evaluation of bool([]) in Python?",
                "options": {
                    "A": "True",
                    "B": "False",
                    "C": "None",
                    "D": "TypeError"
                },
                "correct_option": "B",
                "explanation": "Empty collections (such as empty lists [], tuples (), dicts {}, or empty strings '') evaluate to falsy (False) in Python.",
                "difficulty": "Medium"
            }
        ]

    if "loop" in topic_lower:
        return [
            {
                "question": "How many times does this loop execute? for i in range(1, 6): print(i)",
                "options": {
                    "A": "4 times",
                    "B": "5 times",
                    "C": "6 times",
                    "D": "Infinitely"
                },
                "correct_option": "B",
                "explanation": "range(start, stop) generates numbers starting at 1 up to but not including 6 (1, 2, 3, 4, 5), executing exactly 5 times.",
                "difficulty": "Beginner"
            },
            {
                "question": "Which keyword immediately exits the nearest enclosing loop?",
                "options": {
                    "A": "continue",
                    "B": "pass",
                    "C": "break",
                    "D": "return"
                },
                "correct_option": "C",
                "explanation": "The 'break' statement terminates the current loop execution and resumes at the next statement outside the loop.",
                "difficulty": "Beginner"
            },
            {
                "question": "What does the 'continue' statement do when encountered inside a loop?",
                "options": {
                    "A": "Exits the program completely",
                    "B": "Skips the rest of the current iteration and advances to the next",
                    "C": "Restarts the loop from index 0",
                    "D": "Executes the loop backwards"
                },
                "correct_option": "B",
                "explanation": "'continue' ends the current iteration prematurely and jumps directly to the loop condition/next item.",
                "difficulty": "Medium"
            },
            {
                "question": "What happens if a while loop condition is 'count < 5' but 'count' is never incremented?",
                "options": {
                    "A": "The loop finishes immediately",
                    "B": "The loop throws a ZeroDivisionError",
                    "C": "An infinite loop occurs",
                    "D": "Python automatically increments count by 1"
                },
                "correct_option": "C",
                "explanation": "If the loop condition remains truthy and state variables never update towards termination, the loop runs infinitely.",
                "difficulty": "Beginner"
            },
            {
                "question": "What will range(0, 10, 3) yield when converted to a list?",
                "options": {
                    "A": "[0, 3, 6, 9]",
                    "B": "[3, 6, 9]",
                    "C": "[0, 1, 2, 3]",
                    "D": "[0, 3, 6, 9, 10]"
                },
                "correct_option": "A",
                "explanation": "With step 3, values start at 0 and advance by 3 while strictly less than 10: giving 0, 3, 6, 9.",
                "difficulty": "Medium"
            }
        ]

    # Universal questions tailored to the topic and subject
    return [
        {
            "question": f"What is the primary role of '{topic_name}' in {subject}?",
            "options": {
                "A": f"To structure and control fundamental operations relating to {topic_name}",
                "B": "To bypass the language compiler or interpreter entirely",
                "C": "To serve purely as optional cosmetic formatting",
                "D": "To terminate the application runtime prematurely"
            },
            "correct_option": "A",
            "explanation": f"{topic_name} forms an essential core building block in {subject} for structuring code and managing operations predictably.",
            "difficulty": "Beginner"
        },
        {
            "question": f"Which best practice applies when implementing {topic_name} at an {knowledge_level} level?",
            "options": {
                "A": "Hardcoding magic numbers and values directly into logic",
                "B": "Writing clean, modular, and self-documenting code with defensive validation",
                "C": "Ignoring error checks and assuming external data is always pristine",
                "D": "Writing all logic in a single monolithic block without comments"
            },
            "correct_option": "B",
            "explanation": "Writing modular, well-tested code with explicit error checks is the industry standard across all software engineering disciplines.",
            "difficulty": "Medium"
        },
        {
            "question": f"When debugging an unexpected issue in {topic_name}, what is the recommended first step?",
            "options": {
                "A": "Immediately delete and rewrite the entire repository",
                "B": "Inspect the error traceback, verify input parameters, and isolate with a minimal test case",
                "C": "Ignore warning messages and deploy to production",
                "D": "Randomly change variable names until it compiles"
            },
            "correct_option": "B",
            "explanation": "Systematic debugging starts by reading the diagnostic message/traceback and isolating inputs with minimal reproducible test cases.",
            "difficulty": "Medium"
        },
        {
            "question": f"How does mastery of {topic_name} contribute to building complete projects in {subject}?",
            "options": {
                "A": "It has no relationship to real-world application building",
                "B": "It enables composition of reliable, reusable components and robust data flows",
                "C": "It is only required for legacy systems older than 20 years",
                "D": "It replaces the need for data structures altogether"
            },
            "correct_option": "B",
            "explanation": "Mastering foundational concepts allows developers to construct maintainable, scalable, and resilient systems.",
            "difficulty": "Beginner"
        },
        {
            "question": f"What common anti-pattern should be avoided when working with {topic_name}?",
            "options": {
                "A": "Writing unit tests to verify expected edge cases",
                "B": "Over-complicating logic with excessive nesting and ignoring boundary conditions",
                "C": "Consulting official documentation when learning new APIs",
                "D": "Using descriptive naming conventions for variables and functions"
            },
            "correct_option": "B",
            "explanation": "Deep nesting and omitting boundary conditions creates brittle code that easily introduces regressions and security vulnerabilities.",
            "difficulty": "Hard"
        }
    ]

# ========================================================================= #
# 3. AI LEARNING ASSISTANT
# ========================================================================= #

def ask_learning_assistant(
    message: str,
    chat_history: List[Dict[str, Any]],
    learner_context: Dict[str, Any]
) -> str:
    """
    Provides context-aware conversational answers tailored to the student's level,
    subject, current topic, and learning style.
    """
    api_key = get_gemini_api_key()
    subject = learner_context.get("subject", "General Technical Subject")
    level = learner_context.get("knowledge_level", "Beginner")
    goal = learner_context.get("goal", "Learn fundamentals")
    style = learner_context.get("learning_style", "Mixed")
    current_topic = learner_context.get("current_topic", "Active Studies")
    weak_topics = learner_context.get("weak_topics", [])

    system_instruction = f"""
You are the AI Personalized Learning Coach for a student learning '{subject}'.
Student Profile:
- Knowledge Level: {level}
- Primary Learning Goal: {goal}
- Learning Style Preference: {style}
- Current Active Study Topic: {current_topic}
- Topics Flagged for Revision: {', '.join(weak_topics) if weak_topics else 'None currently'}

Teaching Guidelines:
1. Explain concepts in a warm, encouraging, student-friendly tone suitable for a {level} level.
2. Use clear analogies, concise code snippets (if relevant), and step-by-step breakdowns.
3. If the student asks for examples, emphasize their preferred learning style ({style}).
4. Keep explanations focused and actionable. Provide 1 quick comprehension check question at the end.
"""

    if api_key:
        # Build prompt including recent conversational context
        conversation_context = ""
        for msg in chat_history[-6:]:
            role = "Student" if msg["role"] == "user" else "Coach"
            conversation_context += f"{role}: {msg['message']}\n"

        prompt = f"""
{conversation_context}
Student: {message}
Coach:
"""
        try:
            return call_gemini(prompt=prompt, system_instruction=system_instruction)
        except Exception as e:
            logger.warning(f"Assistant Gemini call failed: {e}")

    # Fallback response generator
    return (
        f"**Coach Response (Offline Mode):**\n\n"
        f"Great question regarding **{subject}** ({current_topic})!\n\n"
        f"As a **{level}** learner aiming to *{goal}*, here is how to think about this:\n\n"
        f"1. **Core Concept:** In {subject}, break this problem down into smaller logical parts.\n"
        f"2. **Practical Tip ({style} style):** Try writing a 3-line isolated script or test to observe the behavior first-hand.\n"
        f"3. **Next Step:** Check out the interactive Practice Quiz for this topic to test your recall!"
    )

# ========================================================================= #
# 4. PERFORMANCE RECOMMENDATION GENERATOR
# ========================================================================= #

def generate_performance_recommendation(
    score_percentage: float,
    topic_name: str,
    subject: str,
    knowledge_level: str
) -> Dict[str, Any]:
    """
    Generates intelligent adaptive feedback and actionable next steps based on quiz performance.
    Adheres strictly to the pedagogical rule:
    - Never claim mastery based on a single small quiz alone.
    """
    if score_percentage < 40.0:
        category = "Needs Revision"
        summary = f"Foundational review recommended for '{topic_name}'."
        actions = [
            f"Review basic syntax and core principles of {topic_name} before moving on.",
            f"Work through beginner-level walkthrough examples with step-by-step tracing.",
            "Ask the AI Learning Assistant to explain the questions you missed with simple analogies.",
            "Retake the practice quiz after 15 minutes of focused review."
        ]
    elif score_percentage < 70.0:
        category = "Practice Recommended"
        summary = f"Good start, but additional practice is needed for '{topic_name}'."
        actions = [
            f"Review the answer explanations for incorrect questions above.",
            f"Complete 2-3 hands-on mini exercises applying {topic_name}.",
            "Reinforce the key concepts by taking notes on where edge cases occurred.",
            "Attempt another quiz on this topic to solidify your score above 70%."
        ]
    elif score_percentage < 90.0:
        category = "Good Progress"
        summary = f"Solid understanding demonstrated on '{topic_name}'."
        actions = [
            f"You demonstrated strong grasp of {topic_name} fundamentals.",
            "Review the one or two subtle details from the explanations.",
            "You are ready to advance to the next scheduled topic in your study plan.",
            "Note: Consistency across multiple practice sessions will ensure long-term mastery."
        ]
    else:
        category = "Strong Performance"
        summary = f"Outstanding result on '{topic_name}'! Ready for next challenges."
        actions = [
            f"Excellent work scoring {score_percentage:.0f}% on {topic_name}.",
            "Advance to the next day in your study plan or tackle advanced challenge exercises.",
            "Try explaining this topic to a peer or asking the AI Assistant for intermediate edge cases.",
            "Note: Great performance on this quiz! Revisit periodically to maintain retention."
        ]

    return {
        "category": category,
        "score_percentage": score_percentage,
        "summary": summary,
        "actions": actions
    }

