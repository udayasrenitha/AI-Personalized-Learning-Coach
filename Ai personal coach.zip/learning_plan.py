"""
Learning Plan Manager for AI Personalized Learning Coach.
Handles curriculum generation, regeneration, validation, topic tracking,
and card rendering helpers.
"""

from typing import Dict, Any, List, Tuple, Optional
import database
import ai_service

def validate_plan_inputs(
    subject: str,
    goal: str,
    knowledge_level: str,
    target_days: int,
    daily_minutes: int,
    learning_style: str
) -> Tuple[bool, Optional[str]]:
    """
    Validates learner plan inputs before generating.
    Returns (is_valid, error_message).
    """
    if not subject or not subject.strip():
        return False, "Please enter a valid subject to learn (e.g., Python, Machine Learning, SQL)."

    if not goal or not goal.strip():
        return False, "Please describe your learning goal (e.g., Prepare for technical interviews)."

    if len(subject.strip()) < 2:
        return False, "Subject name must be at least 2 characters long."

    if len(goal.strip()) < 5:
        return False, "Goal must be at least 5 characters long to provide sufficient context for the AI."

    if not isinstance(target_days, int) or target_days < 1 or target_days > 90:
        return False, "Target duration must be between 1 and 90 days."

    if not isinstance(daily_minutes, int) or daily_minutes < 10 or daily_minutes > 360:
        return False, "Daily study time must be between 10 and 360 minutes."

    valid_levels = ["Beginner", "Intermediate", "Advanced"]
    if knowledge_level not in valid_levels:
        return False, f"Knowledge level must be one of {valid_levels}."

    valid_styles = ["Reading", "Examples", "Practice", "Mixed"]
    if learning_style not in valid_styles:
        return False, f"Learning style must be one of {valid_styles}."

    return True, None

def create_and_save_study_plan(
    learner_id: int,
    subject: str,
    goal: str,
    knowledge_level: str,
    target_days: int,
    daily_minutes: int,
    learning_style: str
) -> Tuple[bool, Any]:
    """
    Validates, requests AI plan generation, and persists to SQLite database.
    Returns (success, plan_id_or_error_message).
    """
    is_valid, err = validate_plan_inputs(
        subject, goal, knowledge_level, target_days, daily_minutes, learning_style
    )
    if not is_valid:
        return False, err

    try:
        # Call AI service
        plan_data = ai_service.generate_study_plan_ai(
            subject=subject.strip(),
            goal=goal.strip(),
            knowledge_level=knowledge_level,
            target_days=target_days,
            daily_minutes=daily_minutes,
            learning_style=learning_style
        )

        topics = plan_data.get("topics", [])
        if not topics:
            return False, "AI generation did not return valid topics. Please try again."

        summary = plan_data.get("summary", f"{target_days}-day study plan for {subject}.")

        # Save to database
        plan_id = database.save_study_plan(
            learner_id=learner_id,
            subject=subject.strip(),
            goal=goal.strip(),
            total_days=target_days,
            summary=summary,
            topics_data=topics
        )

        return True, plan_id

    except Exception as e:
        return False, f"Failed to generate study plan: {str(e)}"

def regenerate_current_plan(learner_id: int) -> Tuple[bool, Any]:
    """
    Regenerates the active study plan using the learner's existing profile.
    """
    learner = database.get_learner_by_id(learner_id)
    if not learner:
        return False, "Learner profile not found."

    return create_and_save_study_plan(
        learner_id=learner["id"],
        subject=learner["subject"],
        goal=learner["goal"],
        knowledge_level=learner["knowledge_level"],
        target_days=learner["target_days"],
        daily_minutes=learner["daily_minutes"],
        learning_style=learner["learning_style"]
    )

