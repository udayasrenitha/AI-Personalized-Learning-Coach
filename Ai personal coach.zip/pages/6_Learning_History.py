"""
Learning History & Archives (Module 8).
Enables students to explore historical study plans, inspect previous quiz attempts
with full question-level reviews, and switch active plans.
"""

import streamlit as st
import pandas as pd
from config import APP_NAME, APP_ICON, apply_custom_theme, render_top_navigation, THEME_COLORS
import database

st.set_page_config(
    page_title=f"{APP_NAME} - Learning History",
    page_icon=APP_ICON,
    layout="wide",
    initial_sidebar_state="collapsed"
)

apply_custom_theme()
render_top_navigation("history")

active_learner = database.get_active_learner()

if not active_learner:
    st.warning("⚠️ No active learner profile found. Please set up your profile first.")
    if st.button("👉 Set Up Learner Profile", type="primary"):
        st.switch_page("pages/1_Learning_Profile.py")
    st.stop()

# Header
st.markdown(
    f"""
    <div style="margin-bottom: 20px;">
        <span class="badge badge-purple">Module 8</span>
        <h1 style="color: #1E1B4B; margin: 6px 0 6px 0;">Learning History & Archives</h1>
        <p style="color: #64748B; font-size: 1rem; margin: 0;">
            Persistent archive of all study plans, quiz evaluations, score trajectories, and coaching recommendations.
        </p>
    </div>
    """,
    unsafe_allow_html=True
)

tab1, tab2, tab3 = st.tabs(["📚 Saved Study Plans", "📝 Past Quiz Attempts", "🎯 Completed Topics"])

# ========================================================================= #
# TAB 1: SAVED STUDY PLANS
# ========================================================================= #
with tab1:
    st.markdown("### 📚 Saved Study Plans for Current Learner")
    plans = database.get_all_study_plans(learner_id=active_learner["id"])

    if not plans:
        st.info("No study plans created yet for this profile.")
    else:
        for p in plans:
            is_active = bool(p.get("is_active"))
            active_badge = "<span class='badge badge-success'>Active Plan</span>" if is_active else "<span class='badge' style='background: #E2E8F0; color: #475569;'>Archived</span>"
            border_c = THEME_COLORS["primary"] if is_active else "#CBD5E1"

            with st.container():
                st.markdown(
                    f"""
                    <div class="coach-card" style="border-left: 6px solid {border_c}; padding: 18px; margin-bottom: 14px;">
                        <div style="display: flex; justify-content: space-between; align-items: flex-start; flex-wrap: wrap;">
                            <div>
                                <div style="font-size: 0.82rem; color: #7C3AED; font-weight: 700;">Plan #{p['id']} &bull; Created {p['created_at'][:10]}</div>
                                <h3 style="margin: 4px 0 6px 0; color: #1E1B4B;">{p['subject']} — {p['total_days']} Days Curriculum</h3>
                                <p style="color: #64748B; font-size: 0.9rem; margin: 0;"><strong>Goal:</strong> {p['goal']}</p>
                            </div>
                            <div>
                                {active_badge}
                            </div>
                        </div>
                    </div>
                    """,
                    unsafe_allow_html=True
                )

                c_p1, c_p2 = st.columns([1, 1])
                with c_p1:
                    if not is_active:
                        if st.button("Set as Active Plan", key=f"activate_plan_{p['id']}", use_container_width=True):
                            database.set_active_study_plan(active_learner["id"], p["id"])
                            st.success(f"Plan #{p['id']} is now active!")
                            st.rerun()
                    else:
                        st.caption("✓ Currently Active Study Plan")

                with c_p2:
                    if st.button("View Day-by-Day Topics", key=f"view_topics_{p['id']}", use_container_width=True):
                        st.session_state["history_inspect_plan_id"] = p["id"]

        # If user clicked inspect
        if "history_inspect_plan_id" in st.session_state:
            inspect_id = st.session_state["history_inspect_plan_id"]
            st.markdown(f"#### 🔎 Day-wise Topics in Plan #{inspect_id}")
            plan_topics = database.get_plan_topics(inspect_id)
            for pt in plan_topics:
                st.markdown(
                    f"- **Day {pt['day_number']}:** {pt['topic_name']} "
                    f"({'✓ Completed' if pt.get('is_completed') else 'Pending'}) "
                    f"— Last score: {pt.get('last_quiz_score', 0)}%"
                )

# ========================================================================= #
# TAB 2: PAST QUIZ ATTEMPTS & INSPECTION
# ========================================================================= #
with tab2:
    st.markdown("### 📝 Quiz Attempt History & Question Inspections")
    attempts = database.get_quiz_attempts_for_learner(active_learner["id"])

    if not attempts:
        st.info("No quizzes taken yet. Complete quizzes in **3. Practice Quiz** to build your history!")
    else:
        # Select attempt to inspect in detail
        attempt_choices = {
            a["id"]: f"Attempt #{a['id']} - {a['topic_name']} ({a['score_percentage']}%) - {a['created_at'][:16]}"
            for a in attempts
        }
        selected_attempt_id = st.selectbox(
            "Select an attempt to inspect question breakdown:",
            options=list(attempt_choices.keys()),
            format_func=lambda x: attempt_choices[x]
        )

        attempt_details = database.get_quiz_attempt_details(selected_attempt_id)
        if attempt_details:
            st.markdown(
                f"""
                <div class="coach-card" style="margin-top: 14px; background: #FAF5FF; border-left: 6px solid {THEME_COLORS['primary']};">
                    <h4 style="margin: 0 0 6px 0; color: #1E1B4B;">Attempt #{attempt_details['id']}: {attempt_details['topic_name']}</h4>
                    <p style="margin: 0; color: #475569; font-size: 0.92rem;">
                        Score: <strong>{attempt_details['score_percentage']}%</strong> ({attempt_details['correct_answers']}/{attempt_details['total_questions']} correct) &bull; 
                        Status: <strong>{attempt_details['status']}</strong> &bull; Date: {attempt_details['created_at']}
                    </p>
                    <div style="margin-top: 8px; font-size: 0.88rem; color: #6D28D9;">
                        <strong>Recommendation:</strong> {attempt_details.get('recommendation', 'N/A')}
                    </div>
                </div>
                """,
                unsafe_allow_html=True
            )

            # Questions breakdown
            st.markdown("##### 🔍 Question Details for This Attempt")
            for idx, q in enumerate(attempt_details.get("questions", [])):
                is_correct = bool(q.get("is_correct"))
                icon = "✅" if is_correct else "❌"
                border_c = "#10B981" if is_correct else "#EF4444"

                st.markdown(
                    f"""
                    <div style="background: #FFFFFF; border: 1px solid #EDE9FE; border-left: 5px solid {border_c}; border-radius: 8px; padding: 12px; margin-bottom: 10px;">
                        <div style="display: flex; justify-content: space-between; font-size: 0.85rem; margin-bottom: 4px;">
                            <strong>Q{idx + 1}: {icon} {'Correct' if is_correct else 'Incorrect'}</strong>
                            <span>Selected: <strong>{q.get('user_selected_option')}</strong> | Correct: <strong>{q.get('correct_option')}</strong></span>
                        </div>
                        <div style="font-size: 0.95rem; color: #1E1B4B; margin-bottom: 6px;">{q.get('question_text')}</div>
                        <div style="font-size: 0.85rem; color: #4C1D95; background: #F5F3FF; padding: 6px 10px; border-radius: 6px;">
                            <strong>Explanation:</strong> {q.get('explanation')}
                        </div>
                    </div>
                    """,
                    unsafe_allow_html=True
                )

# ========================================================================= #
# TAB 3: COMPLETED TOPICS LOG
# ========================================================================= #
with tab3:
    st.markdown("### 🎯 Completed Topics Milestone Log")
    active_plan = database.get_active_study_plan(active_learner["id"])

    if not active_plan:
        st.info("No active plan to display completed topics.")
    else:
        topics = database.get_plan_topics(active_plan["id"])
        completed_topics = [t for t in topics if t.get("is_completed")]

        if not completed_topics:
            st.info("You haven't marked any topics as completed yet. Complete days in your **Study Plan** to log milestones!")
        else:
            for ct in completed_topics:
                st.markdown(
                    f"""
                    <div style="background: #FFFFFF; border: 1px solid #A7F3D0; border-left: 5px solid #10B981; border-radius: 10px; padding: 14px; margin-bottom: 10px;">
                        <div style="display: flex; justify-content: space-between; align-items: center;">
                            <div>
                                <span class="badge badge-success">Day {ct['day_number']} Completed</span>
                                <h4 style="margin: 4px 0 2px 0; color: #1E1B4B;">{ct['topic_name']}</h4>
                                <span style="font-size: 0.82rem; color: #64748B;">Completed at: {ct.get('completed_at', 'Recorded in database')}</span>
                            </div>
                            <div>
                                <span style="font-weight: 700; color: #065F46;">Last Quiz: {ct.get('last_quiz_score', 0)}%</span>
                            </div>
                        </div>
                    </div>
                    """,
                    unsafe_allow_html=True
                )

