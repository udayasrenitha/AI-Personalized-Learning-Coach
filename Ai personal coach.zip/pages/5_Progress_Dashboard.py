"""
Student Progress Dashboard (Module 7).
Interactive analytics portal powered by Plotly and SQLite data.
Displays completion metrics, score progressions, weak topics, and adaptive recommendations.
"""

import streamlit as st
import pandas as pd
from config import APP_NAME, APP_ICON, apply_custom_theme, render_top_navigation, THEME_COLORS
import database
import dashboard
import performance_analyzer

st.set_page_config(
    page_title=f"{APP_NAME} - Progress Dashboard",
    page_icon=APP_ICON,
    layout="wide",
    initial_sidebar_state="collapsed"
)

apply_custom_theme()
render_top_navigation("dashboard")

active_learner = database.get_active_learner()

if not active_learner:
    st.warning("⚠️ No active learner profile found. Please set up your profile first.")
    if st.button("👉 Set Up Learner Profile", type="primary"):
        st.switch_page("pages/1_Learning_Profile.py")
    st.stop()

# Header
st.markdown(
    f"""
    <div style="margin-bottom: 20px;">
        <span class="badge badge-purple">Module 7</span>
        <h1 style="color: #1E1B4B; margin: 6px 0 6px 0;">Student Progress & Analytics Dashboard</h1>
        <p style="color: #64748B; font-size: 1rem; margin: 0;">
            Comprehensive performance analytics for <strong>{active_learner['name']}</strong> &bull; Subject: <strong>{active_learner['subject']}</strong>
        </p>
    </div>
    """,
    unsafe_allow_html=True
)

# Fetch real database analytics
summary = database.get_learner_progress_summary(active_learner["id"])
perf_analysis = performance_analyzer.analyze_learner_performance(active_learner["id"])
weak_topics = perf_analysis["weaknesses"]
strengths = perf_analysis["strengths"]
rec_next = perf_analysis["recommended_next"]

# --- RECOMMENDED NEXT ACTION HERO CARD ---
st.markdown(
    f"""
    <div class="coach-card" style="border-left: 6px solid {THEME_COLORS['primary']}; background: #FAF5FF; margin-bottom: 24px;">
        <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px;">
            <div>
                <span class="badge badge-{rec_next.get('badge_color', 'purple')}">Next Priority Milestone</span>
                <h3 style="margin: 6px 0 4px 0; color: #1E1B4B;">{rec_next['action']}: {rec_next['topic_name']}</h3>
                <p style="margin: 0; color: #64748B; font-size: 0.92rem;">
                    {rec_next['reason']}
                </p>
            </div>
        </div>
    </div>
    """,
    unsafe_allow_html=True
)

btn_c1, btn_c2 = st.columns([1, 3])
with btn_c1:
    if st.button("🚀 Continue Learning", type="primary", use_container_width=True):
        if rec_next.get("topic_id"):
            st.session_state["selected_quiz_topic_id"] = rec_next["topic_id"]
            st.switch_page("pages/3_Practice_Quiz.py")
        else:
            st.switch_page("pages/2_Study_Plan.py")

st.markdown("<div style='margin-bottom: 20px;'></div>", unsafe_allow_html=True)

# --- 7 CORE REAL DATABASE METRIC CARDS ---
st.markdown("### 📊 High-Level Performance Metrics")
m1, m2, m3, m4, m5, m6, m7 = st.columns(7)

with m1:
    st.markdown(
        f"""
        <div class="stat-card">
            <div class="stat-value">{summary['total_plans']}</div>
            <div class="stat-label">Study Plans</div>
        </div>
        """,
        unsafe_allow_html=True
    )

with m2:
    st.markdown(
        f"""
        <div class="stat-card">
            <div class="stat-value">{summary['total_topics']}</div>
            <div class="stat-label">Total Topics</div>
        </div>
        """,
        unsafe_allow_html=True
    )

with m3:
    st.markdown(
        f"""
        <div class="stat-card">
            <div class="stat-value" style="color: #10B981;">{summary['completed_topics']}</div>
            <div class="stat-label">Completed</div>
        </div>
        """,
        unsafe_allow_html=True
    )

with m4:
    st.markdown(
        f"""
        <div class="stat-card">
            <div class="stat-value" style="color: #64748B;">{summary['pending_topics']}</div>
            <div class="stat-label">Pending</div>
        </div>
        """,
        unsafe_allow_html=True
    )

with m5:
    st.markdown(
        f"""
        <div class="stat-card">
            <div class="stat-value">{summary['quizzes_attempted']}</div>
            <div class="stat-label">Quizzes Taken</div>
        </div>
        """,
        unsafe_allow_html=True
    )

with m6:
    score_color = "#10B981" if summary['average_score'] >= 70.0 else ("#F59E0B" if summary['average_score'] >= 40.0 else "#EF4444")
    st.markdown(
        f"""
        <div class="stat-card">
            <div class="stat-value" style="color: {score_color};">{summary['average_score']}%</div>
            <div class="stat-label">Avg Quiz Score</div>
        </div>
        """,
        unsafe_allow_html=True
    )

with m7:
    st.markdown(
        f"""
        <div class="stat-card">
            <div class="stat-value" style="color: #7C3AED;">{summary['progress_percentage']}%</div>
            <div class="stat-label">Plan Progress</div>
        </div>
        """,
        unsafe_allow_html=True
    )

st.markdown("<div style='margin-bottom: 24px;'></div>", unsafe_allow_html=True)

# --- VISUALIZATION CHARTS ---
st.markdown("### 📈 Interactive Progress Visualizations")

chart_row1_c1, chart_row1_c2 = st.columns([1, 2])

with chart_row1_c1:
    st.markdown(
        """
        <div class="coach-card" style="padding: 16px;">
            <h4 style="margin: 0 0 10px 0; color: #1E1B4B; font-size: 1rem;">Topic Completion Ratio</h4>
        </div>
        """,
        unsafe_allow_html=True
    )
    donut_fig = dashboard.create_completion_donut_chart(
        completed=summary["completed_topics"],
        pending=summary["pending_topics"]
    )
    st.plotly_chart(donut_fig, use_container_width=True)

with chart_row1_c2:
    st.markdown(
        """
        <div class="coach-card" style="padding: 16px;">
            <h4 style="margin: 0 0 10px 0; color: #1E1B4B; font-size: 1rem;">Quiz Score History & Trajectory</h4>
        </div>
        """,
        unsafe_allow_html=True
    )
    history_fig = dashboard.create_quiz_score_history_chart(active_learner["id"])
    st.plotly_chart(history_fig, use_container_width=True)

# Row 2: Topic-wise Performance Bar Chart
st.markdown(
    """
    <div class="coach-card" style="padding: 16px; margin-top: 10px;">
        <h4 style="margin: 0 0 10px 0; color: #1E1B4B; font-size: 1rem;">Topic-Wise Performance Comparison</h4>
    </div>
    """,
    unsafe_allow_html=True
)
bar_fig = dashboard.create_topic_performance_bar_chart(active_learner["id"])
st.plotly_chart(bar_fig, use_container_width=True)

st.markdown("<div style='margin-bottom: 20px;'></div>", unsafe_allow_html=True)

# --- STRENGTHS & WEAK TOPICS SECTION ---
col_weak, col_str = st.columns(2)

with col_weak:
    st.markdown(
        """
        <div class="coach-card" style="border-left: 6px solid #EF4444; height: 100%;">
            <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 12px;">
                <h4 style="color: #991B1B; margin: 0;">⚠️ Topics Requiring Revision (&lt; 70%)</h4>
                <span class="badge badge-danger">Priority Action</span>
            </div>
        """,
        unsafe_allow_html=True
    )
    if not weak_topics:
        st.success("🎉 Great job! No topics currently flagged for revision. Keep up the high standards!")
    else:
        for w in weak_topics:
            st.markdown(
                f"""
                <div style="background: #FEF2F2; border: 1px solid #FECACA; border-radius: 8px; padding: 10px 14px; margin-bottom: 8px;">
                    <div style="display: flex; justify-content: space-between; align-items: center;">
                        <strong>{w['topic_name']}</strong>
                        <span style="color: #DC2626; font-weight: bold;">{w['average_score']}% Avg ({w['attempts_count']} attempts)</span>
                    </div>
                </div>
                """,
                unsafe_allow_html=True
            )
    st.markdown("</div>", unsafe_allow_html=True)

with col_str:
    st.markdown(
        """
        <div class="coach-card" style="border-left: 6px solid #10B981; height: 100%;">
            <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 12px;">
                <h4 style="color: #065F46; margin: 0;">🌟 Demonstrated Strengths (&ge; 70%)</h4>
                <span class="badge badge-success">Solid Grasp</span>
            </div>
        """,
        unsafe_allow_html=True
    )
    if not strengths:
        st.info("💡 Take practice quizzes to discover and build your strongest technical areas!")
    else:
        for s in strengths:
            st.markdown(
                f"""
                <div style="background: #ECFDF5; border: 1px solid #A7F3D0; border-radius: 8px; padding: 10px 14px; margin-bottom: 8px;">
                    <div style="display: flex; justify-content: space-between; align-items: center;">
                        <strong>{s['topic_name']}</strong>
                        <span style="color: #059669; font-weight: bold;">{s['average_score']}% Avg ({s['attempts_count']} attempts)</span>
                    </div>
                </div>
                """,
                unsafe_allow_html=True
            )
    st.markdown("</div>", unsafe_allow_html=True)

# --- RECENT QUIZ ATTEMPTS TABLE ---
st.markdown("---")
st.markdown("### 🕒 Recent Learning Activity")

attempts = database.get_quiz_attempts_for_learner(active_learner["id"], limit=10)
if not attempts:
    st.caption("No quiz attempts recorded yet.")
else:
    df_attempts = pd.DataFrame(attempts)
    df_display = df_attempts[["id", "topic_name", "score_percentage", "status", "created_at"]].copy()
    df_display.columns = ["Attempt ID", "Topic Name", "Score %", "Status", "Date & Time"]
    df_display["Score %"] = df_display["Score %"].apply(lambda v: f"{v:.1f}%")
    st.dataframe(df_display, use_container_width=True, hide_index=True)

