"""
AI Learning Assistant (Module 6).
An interactive, context-aware 24/7 educational AI tutor powered by Gemini.
Maintains session conversation memory, answers technical questions, provides analogies,
and suggests revision drills.
"""

import streamlit as st
from config import APP_NAME, APP_ICON, apply_custom_theme, render_top_navigation, THEME_COLORS
import database
import learning_assistant

st.set_page_config(
    page_title=f"{APP_NAME} - AI Assistant",
    page_icon=APP_ICON,
    layout="wide",
    initial_sidebar_state="collapsed"
)

apply_custom_theme()
render_top_navigation("assistant")

active_learner = database.get_active_learner()

if not active_learner:
    st.warning("⚠️ No active learner profile found. Please set up your profile first.")
    if st.button("👉 Set Up Learner Profile", type="primary"):
        st.switch_page("pages/1_Learning_Profile.py")
    st.stop()

# Get learner context
context = learning_assistant.get_learner_context_dict(active_learner["id"])

# Header
st.markdown(
    f"""
    <div style="margin-bottom: 20px;">
        <span class="badge badge-purple">Module 6</span>
        <h1 style="color: #1E1B4B; margin: 6px 0 6px 0;">AI Learning Assistant & Tutor</h1>
        <p style="color: #64748B; font-size: 1rem; margin: 0;">
            Ask questions, request intuitive analogies, debug tricky errors, or ask for targeted revision drills.
        </p>
    </div>
    """,
    unsafe_allow_html=True
)

# Active Context Banner
st.markdown(
    f"""
    <div class="coach-card" style="padding: 14px 20px; background: #FAF5FF; border-left: 5px solid {THEME_COLORS['primary']}; margin-bottom: 20px;">
        <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 8px;">
            <div>
                <strong style="color: #1E1B4B;">Tutoring Context:</strong>
                <span style="color: #4C1D95; font-size: 0.92rem; margin-left: 6px;">
                    Subject: <strong>{context.get('subject')}</strong> | Level: <strong>{context.get('knowledge_level')}</strong> | 
                    Active Topic: <strong>{context.get('current_topic')}</strong>
                </span>
            </div>
            <div>
                <span class="badge badge-purple">Gemini Powered</span>
            </div>
        </div>
    </div>
    """,
    unsafe_allow_html=True
)

# Suggested Quick Prompt Chips
st.markdown("##### 💡 Suggested Questions (Click to Ask Immediately)")
q_col1, q_col2, q_col3 = st.columns(3)

clicked_prompt = None

with q_col1:
    if st.button(f"🔍 Explain '{context.get('current_topic', 'Active Topic')[:22]}' with a simple analogy", use_container_width=True):
        clicked_prompt = f"Can you explain {context.get('current_topic')} to me using a simple, real-world analogy appropriate for a {context.get('knowledge_level')} student?"

with q_col2:
    if st.button("💻 Show a practical code example with comments", use_container_width=True):
        clicked_prompt = f"Show me a clean, practical code example demonstrating {context.get('current_topic')} in {context.get('subject')} with line-by-line comments."

with q_col3:
    if st.button("🐛 Common beginner mistakes and how to avoid them", use_container_width=True):
        clicked_prompt = f"What are the top 3 mistakes beginners make when learning {context.get('current_topic')}, and how do I avoid them?"

# Check if navigated here with prefilled topic
if "prefill_chat_topic" in st.session_state and st.session_state["prefill_chat_topic"]:
    prefill = st.session_state.pop("prefill_chat_topic")
    clicked_prompt = f"I am currently studying '{prefill}'. Could you summarize the main concepts and give me a 10-minute practice exercise?"

st.markdown("<div style='margin-bottom: 16px;'></div>", unsafe_allow_html=True)

# Chat History Area
chat_container = st.container()

# Load persisted chat history from SQLite
persisted_messages = database.get_chat_history(active_learner["id"], limit=50)

with chat_container:
    if not persisted_messages:
        st.markdown(
            f"""
            <div style="text-align: center; padding: 40px 20px; background: #FFFFFF; border-radius: 16px; border: 1px dashed #DDD6FE; margin-bottom: 20px;">
                <div style="font-size: 2.5rem; margin-bottom: 10px;">👋</div>
                <h3 style="color: #1E1B4B; margin: 0 0 8px 0;">Hello {active_learner['name']}! I'm your AI Learning Coach.</h3>
                <p style="color: #64748B; max-width: 520px; margin: 0 auto 16px auto; font-size: 0.95rem;">
                    I have full context on your {active_learner['subject']} goal and progress.
                    Ask any question, or click one of the suggested prompts above!
                </p>
            </div>
            """,
            unsafe_allow_html=True
        )
    else:
        for msg in persisted_messages:
            role = msg["role"]
            content = msg["message"]
            if role == "user":
                with st.chat_message("user", avatar="👤"):
                    st.markdown(content)
            else:
                with st.chat_message("assistant", avatar="🎓"):
                    st.markdown(content)

# Chat Input & Prompt Handling
user_input = st.chat_input("Type your question about your subject, concepts, or code...")

prompt_to_process = clicked_prompt if clicked_prompt else user_input

if prompt_to_process:
    # Display user message immediately
    with st.chat_message("user", avatar="👤"):
        st.markdown(prompt_to_process)

    # Process and stream assistant response
    with st.chat_message("assistant", avatar="🎓"):
        with st.spinner("AI Learning Coach is thinking..."):
            response_text = learning_assistant.process_user_chat_message(
                learner_id=active_learner["id"],
                user_message=prompt_to_process
            )
            st.markdown(response_text)

    st.rerun()

# Controls Footer
st.markdown("---")
c_foot1, c_foot2 = st.columns([3, 1])
with c_foot1:
    st.caption("Chat history is persistently saved to SQLite. Your coach maintains context across conversations.")
with c_foot2:
    if persisted_messages:
        if st.button("🗑️ Clear Chat History", use_container_width=True):
            database.clear_chat_history(active_learner["id"])
            st.success("Chat history cleared.")
            st.rerun()

