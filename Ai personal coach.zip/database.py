"""
SQLite Database Layer for AI Personalized Learning Coach.
Handles all persistence for learners, study plans, topics, quizzes, progress, and chat.
"""

import sqlite3
import json
import os
from typing import List, Dict, Any, Optional
from datetime import datetime

DB_FILE = "learning_coach.db"

def get_connection() -> sqlite3.Connection:
    """Creates a database connection with foreign key support enabled and dictionary-like row access."""
    conn = sqlite3.connect(DB_FILE, timeout=30.0, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON;")
    return conn

def init_db():
    """Initializes the SQLite database tables if they do not already exist."""
    conn = get_connection()
    with conn:
        cursor = conn.cursor()

        # 1. Learners table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS learners (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                subject TEXT NOT NULL,
                goal TEXT NOT NULL,
                knowledge_level TEXT NOT NULL,
                target_days INTEGER NOT NULL,
                daily_minutes INTEGER NOT NULL,
                learning_style TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
        """)

        # 2. Study Plans table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS study_plans (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                learner_id INTEGER NOT NULL,
                subject TEXT NOT NULL,
                goal TEXT NOT NULL,
                total_days INTEGER NOT NULL,
                summary TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                is_active INTEGER DEFAULT 1,
                FOREIGN KEY (learner_id) REFERENCES learners(id) ON DELETE CASCADE
            );
        """)

        # 3. Study Topics table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS study_topics (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                plan_id INTEGER NOT NULL,
                day_number INTEGER NOT NULL,
                topic_name TEXT NOT NULL,
                objectives TEXT,
                key_concepts TEXT,
                estimated_minutes INTEGER NOT NULL,
                practical_activities TEXT,
                revision_tasks TEXT,
                is_completed INTEGER DEFAULT 0,
                completed_at TIMESTAMP,
                FOREIGN KEY (plan_id) REFERENCES study_plans(id) ON DELETE CASCADE
            );
        """)

        # 4. Quiz Attempts table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS quiz_attempts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                learner_id INTEGER NOT NULL,
                plan_id INTEGER NOT NULL,
                topic_id INTEGER NOT NULL,
                topic_name TEXT NOT NULL,
                total_questions INTEGER NOT NULL,
                correct_answers INTEGER NOT NULL,
                score_percentage REAL NOT NULL,
                status TEXT NOT NULL,
                recommendation TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (learner_id) REFERENCES learners(id) ON DELETE CASCADE,
                FOREIGN KEY (topic_id) REFERENCES study_topics(id) ON DELETE CASCADE
            );
        """)

        # 5. Quiz Questions (individual evaluated questions inside each attempt)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS quiz_questions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                attempt_id INTEGER NOT NULL,
                question_text TEXT NOT NULL,
                option_a TEXT NOT NULL,
                option_b TEXT NOT NULL,
                option_c TEXT NOT NULL,
                option_d TEXT NOT NULL,
                correct_option TEXT NOT NULL,
                user_selected_option TEXT,
                is_correct INTEGER NOT NULL,
                explanation TEXT,
                difficulty TEXT DEFAULT 'Medium',
                FOREIGN KEY (attempt_id) REFERENCES quiz_attempts(id) ON DELETE CASCADE
            );
        """)

        # 6. Learning Progress table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS learning_progress (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                learner_id INTEGER NOT NULL,
                topic_id INTEGER NOT NULL UNIQUE,
                status TEXT DEFAULT 'pending',
                last_quiz_score REAL DEFAULT 0.0,
                needs_revision INTEGER DEFAULT 0,
                attempts_count INTEGER DEFAULT 0,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (learner_id) REFERENCES learners(id) ON DELETE CASCADE,
                FOREIGN KEY (topic_id) REFERENCES study_topics(id) ON DELETE CASCADE
            );
        """)

        # 7. Chat History table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS chat_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                learner_id INTEGER NOT NULL,
                role TEXT NOT NULL,
                message TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (learner_id) REFERENCES learners(id) ON DELETE CASCADE
            );
        """)

        # App state table to store current active learner
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS app_state (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL
            );
        """)

    conn.close()

# ----------------- App State Management ----------------- #

def set_active_learner_id(learner_id: int):
    """Sets the active learner ID in the database."""
    conn = get_connection()
    with conn:
        conn.execute(
            "INSERT OR REPLACE INTO app_state (key, value) VALUES ('active_learner_id', ?)",
            (str(learner_id),)
        )
    conn.close()

def get_active_learner_id() -> Optional[int]:
    """Gets the active learner ID from app_state, or the latest learner if unset."""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT value FROM app_state WHERE key = 'active_learner_id'")
    row = cursor.fetchone()
    if row and row["value"]:
        try:
            learner_id = int(row["value"])
            # verify learner still exists
            cursor.execute("SELECT id FROM learners WHERE id = ?", (learner_id,))
            if cursor.fetchone():
                conn.close()
                return learner_id
        except ValueError:
            pass
    
    # Fallback to the most recent learner
    cursor.execute("SELECT id FROM learners ORDER BY id DESC LIMIT 1")
    fallback = cursor.fetchone()
    conn.close()
    if fallback:
        set_active_learner_id(fallback["id"])
        return fallback["id"]
    return None

# ----------------- Learner Operations ----------------- #

def save_learner(
    name: str,
    subject: str,
    goal: str,
    knowledge_level: str,
    target_days: int,
    daily_minutes: int,
    learning_style: str,
    learner_id: Optional[int] = None
) -> int:
    """Inserts or updates a learner profile."""
    conn = get_connection()
    with conn:
        cursor = conn.cursor()
        if learner_id:
            cursor.execute("""
                UPDATE learners
                SET name = ?, subject = ?, goal = ?, knowledge_level = ?,
                    target_days = ?, daily_minutes = ?, learning_style = ?,
                    updated_at = CURRENT_TIMESTAMP
                WHERE id = ?
            """, (name, subject, goal, knowledge_level, target_days, daily_minutes, learning_style, learner_id))
            lid = learner_id
        else:
            cursor.execute("""
                INSERT INTO learners (name, subject, goal, knowledge_level, target_days, daily_minutes, learning_style)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (name, subject, goal, knowledge_level, target_days, daily_minutes, learning_style))
            lid = cursor.lastrowid
    conn.close()
    if lid:
        set_active_learner_id(lid)
    return lid

def get_learner_by_id(learner_id: int) -> Optional[Dict[str, Any]]:
    """Retrieves learner by ID."""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM learners WHERE id = ?", (learner_id,))
    row = cursor.fetchone()
    conn.close()
    return dict(row) if row else None

def get_active_learner() -> Optional[Dict[str, Any]]:
    """Retrieves the currently selected active learner."""
    lid = get_active_learner_id()
    if lid is None:
        return None
    return get_learner_by_id(lid)

def get_all_learners() -> List[Dict[str, Any]]:
    """Returns all learners sorted by newest first."""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM learners ORDER BY created_at DESC")
    rows = cursor.fetchall()
    conn.close()
    return [dict(r) for r in rows]

# ----------------- Study Plan Operations ----------------- #

def save_study_plan(
    learner_id: int,
    subject: str,
    goal: str,
    total_days: int,
    summary: str,
    topics_data: List[Dict[str, Any]]
) -> int:
    """
    Saves a newly generated study plan and its day-wise topics.
    Sets previous active plans for this learner to inactive.
    """
    conn = get_connection()
    with conn:
        cursor = conn.cursor()
        # Deactivate previous plans for this learner
        cursor.execute("UPDATE study_plans SET is_active = 0 WHERE learner_id = ?", (learner_id,))

        cursor.execute("""
            INSERT INTO study_plans (learner_id, subject, goal, total_days, summary, is_active)
            VALUES (?, ?, ?, ?, ?, 1)
        """, (learner_id, subject, goal, total_days, summary))
        plan_id = cursor.lastrowid

        for topic in topics_data:
            obj_str = json.dumps(topic.get("objectives", [])) if isinstance(topic.get("objectives"), list) else str(topic.get("objectives", ""))
            key_str = json.dumps(topic.get("key_concepts", [])) if isinstance(topic.get("key_concepts"), list) else str(topic.get("key_concepts", ""))
            act_str = json.dumps(topic.get("practical_activities", [])) if isinstance(topic.get("practical_activities"), list) else str(topic.get("practical_activities", ""))
            rev_str = json.dumps(topic.get("revision_tasks", [])) if isinstance(topic.get("revision_tasks"), list) else str(topic.get("revision_tasks", ""))

            cursor.execute("""
                INSERT INTO study_topics (
                    plan_id, day_number, topic_name, objectives, key_concepts,
                    estimated_minutes, practical_activities, revision_tasks, is_completed
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0)
            """, (
                plan_id,
                topic.get("day_number", 1),
                topic.get("topic_name", "Untitled Topic"),
                obj_str,
                key_str,
                int(topic.get("estimated_minutes", 45)),
                act_str,
                rev_str
            ))
            topic_id = cursor.lastrowid

            # Initialize learning progress record for this topic
            cursor.execute("""
                INSERT OR IGNORE INTO learning_progress (learner_id, topic_id, status, last_quiz_score, needs_revision, attempts_count)
                VALUES (?, ?, 'pending', 0.0, 0, 0)
            """, (learner_id, topic_id))

    conn.close()
    return plan_id

def get_active_study_plan(learner_id: int) -> Optional[Dict[str, Any]]:
    """Gets the active study plan for a learner."""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT * FROM study_plans
        WHERE learner_id = ? AND is_active = 1
        ORDER BY id DESC LIMIT 1
    """, (learner_id,))
    row = cursor.fetchone()
    conn.close()
    return dict(row) if row else None

def get_study_plan_by_id(plan_id: int) -> Optional[Dict[str, Any]]:
    """Gets a specific study plan by ID."""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM study_plans WHERE id = ?", (plan_id,))
    row = cursor.fetchone()
    conn.close()
    return dict(row) if row else None

def set_active_study_plan(learner_id: int, plan_id: int):
    """Sets a specific study plan as active for the learner."""
    conn = get_connection()
    with conn:
        conn.execute("UPDATE study_plans SET is_active = 0 WHERE learner_id = ?", (learner_id,))
        conn.execute("UPDATE study_plans SET is_active = 1 WHERE id = ? AND learner_id = ?", (plan_id, learner_id))
    conn.close()

def get_all_study_plans(learner_id: Optional[int] = None) -> List[Dict[str, Any]]:
    """Returns all study plans, optionally filtered by learner."""
    conn = get_connection()
    cursor = conn.cursor()
    if learner_id:
        cursor.execute("SELECT * FROM study_plans WHERE learner_id = ? ORDER BY created_at DESC", (learner_id,))
    else:
        cursor.execute("SELECT * FROM study_plans ORDER BY created_at DESC")
    rows = cursor.fetchall()
    conn.close()
    return [dict(r) for r in rows]

def get_plan_topics(plan_id: int) -> List[Dict[str, Any]]:
    """Fetches all topics belonging to a plan, with parsed JSON lists and completion status."""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT t.*, p.status as progress_status, p.last_quiz_score, p.needs_revision, p.attempts_count
        FROM study_topics t
        LEFT JOIN learning_progress p ON t.id = p.topic_id
        WHERE t.plan_id = ?
        ORDER BY t.day_number ASC
    """, (plan_id,))
    rows = cursor.fetchall()
    conn.close()

    result = []
    for r in rows:
        d = dict(r)
        # Parse JSON fields safely
        for field in ["objectives", "key_concepts", "practical_activities", "revision_tasks"]:
            raw = d.get(field)
            if raw:
                try:
                    d[field] = json.loads(raw)
                except Exception:
                    d[field] = [raw]
            else:
                d[field] = []
        result.append(d)
    return result

def get_topic_by_id(topic_id: int) -> Optional[Dict[str, Any]]:
    """Fetches single topic details by ID."""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT t.*, p.status as progress_status, p.last_quiz_score, p.needs_revision, p.attempts_count
        FROM study_topics t
        LEFT JOIN learning_progress p ON t.id = p.topic_id
        WHERE t.id = ?
    """, (topic_id,))
    row = cursor.fetchone()
    conn.close()
    if not row:
        return None
    d = dict(row)
    for field in ["objectives", "key_concepts", "practical_activities", "revision_tasks"]:
        raw = d.get(field)
        if raw:
            try:
                d[field] = json.loads(raw)
            except Exception:
                d[field] = [raw]
        else:
            d[field] = []
    return d

def toggle_topic_completion(topic_id: int, is_completed: bool):
    """Marks a topic as completed or pending."""
    completed_val = 1 if is_completed else 0
    completed_time = datetime.now().isoformat() if is_completed else None
    progress_status = 'completed' if is_completed else 'pending'

    conn = get_connection()
    with conn:
        conn.execute("""
            UPDATE study_topics
            SET is_completed = ?, completed_at = ?
            WHERE id = ?
        """, (completed_val, completed_time, topic_id))

        conn.execute("""
            UPDATE learning_progress
            SET status = ?, updated_at = CURRENT_TIMESTAMP
            WHERE topic_id = ?
        """, (progress_status, topic_id))
    conn.close()

# ----------------- Quiz Operations ----------------- #

def save_quiz_attempt(
    learner_id: int,
    plan_id: int,
    topic_id: int,
    topic_name: str,
    total_questions: int,
    correct_answers: int,
    score_percentage: float,
    status: str,
    recommendation: str,
    questions_evaluated: List[Dict[str, Any]]
) -> int:
    """
    Saves a completed quiz attempt, each evaluated question, and updates topic learning progress.
    """
    conn = get_connection()
    with conn:
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO quiz_attempts (
                learner_id, plan_id, topic_id, topic_name, total_questions,
                correct_answers, score_percentage, status, recommendation
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            learner_id, plan_id, topic_id, topic_name, total_questions,
            correct_answers, score_percentage, status, recommendation
        ))
        attempt_id = cursor.lastrowid

        for q in questions_evaluated:
            cursor.execute("""
                INSERT INTO quiz_questions (
                    attempt_id, question_text, option_a, option_b, option_c, option_d,
                    correct_option, user_selected_option, is_correct, explanation, difficulty
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                attempt_id,
                q.get("question", ""),
                q.get("options", {}).get("A", ""),
                q.get("options", {}).get("B", ""),
                q.get("options", {}).get("C", ""),
                q.get("options", {}).get("D", ""),
                str(q.get("correct_option", "A")).upper().strip(),
                str(q.get("user_selected_option", "")).upper().strip(),
                1 if q.get("is_correct") else 0,
                q.get("explanation", ""),
                q.get("difficulty", "Medium")
            ))

        # Update learning progress
        needs_revision = 1 if score_percentage < 70.0 else 0
        cursor.execute("""
            INSERT INTO learning_progress (learner_id, topic_id, status, last_quiz_score, needs_revision, attempts_count)
            VALUES (?, ?, ?, ?, ?, 1)
            ON CONFLICT(topic_id) DO UPDATE SET
                last_quiz_score = excluded.last_quiz_score,
                needs_revision = excluded.needs_revision,
                attempts_count = attempts_count + 1,
                updated_at = CURRENT_TIMESTAMP
        """, (learner_id, topic_id, 'in_progress', score_percentage, needs_revision))

    conn.close()
    return attempt_id

def get_quiz_attempts_for_learner(learner_id: int, limit: Optional[int] = None) -> List[Dict[str, Any]]:
    """Retrieves all quiz attempts for a learner."""
    conn = get_connection()
    cursor = conn.cursor()
    query = "SELECT * FROM quiz_attempts WHERE learner_id = ? ORDER BY created_at DESC"
    if limit:
        query += f" LIMIT {int(limit)}"
    cursor.execute(query, (learner_id,))
    rows = cursor.fetchall()
    conn.close()
    return [dict(r) for r in rows]

def get_quiz_attempt_details(attempt_id: int) -> Optional[Dict[str, Any]]:
    """Retrieves a single quiz attempt with all its questions."""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM quiz_attempts WHERE id = ?", (attempt_id,))
    attempt = cursor.fetchone()
    if not attempt:
        conn.close()
        return None

    attempt_dict = dict(attempt)
    cursor.execute("SELECT * FROM quiz_questions WHERE attempt_id = ?", (attempt_id,))
    questions = cursor.fetchall()
    conn.close()

    attempt_dict["questions"] = [dict(q) for q in questions]
    return attempt_dict

def get_weak_topics(learner_id: int, threshold: float = 70.0) -> List[Dict[str, Any]]:
    """
    Identifies topics that scored below the threshold or are flagged as needing revision.
    """
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT t.id as topic_id, t.topic_name, t.day_number, p.last_quiz_score, p.attempts_count, p.needs_revision
        FROM learning_progress p
        JOIN study_topics t ON p.topic_id = t.id
        WHERE p.learner_id = ? AND (p.last_quiz_score < ? OR p.needs_revision = 1) AND p.attempts_count > 0
        ORDER BY p.last_quiz_score ASC
    """, (learner_id, threshold))
    rows = cursor.fetchall()
    conn.close()
    return [dict(r) for r in rows]

def get_learner_progress_summary(learner_id: int) -> Dict[str, Any]:
    """Computes comprehensive aggregated metrics for dashboard."""
    conn = get_connection()
    cursor = conn.cursor()

    # Active plan
    cursor.execute("SELECT id FROM study_plans WHERE learner_id = ? AND is_active = 1 LIMIT 1", (learner_id,))
    active_plan = cursor.fetchone()
    plan_id = active_plan["id"] if active_plan else None

    # Total plans
    cursor.execute("SELECT COUNT(*) as cnt FROM study_plans WHERE learner_id = ?", (learner_id,))
    total_plans = cursor.fetchone()["cnt"]

    # Topics for active plan
    total_topics = 0
    completed_topics = 0
    pending_topics = 0
    if plan_id:
        cursor.execute("SELECT COUNT(*) as cnt FROM study_topics WHERE plan_id = ?", (plan_id,))
        total_topics = cursor.fetchone()["cnt"]
        cursor.execute("SELECT COUNT(*) as cnt FROM study_topics WHERE plan_id = ? AND is_completed = 1", (plan_id,))
        completed_topics = cursor.fetchone()["cnt"]
        pending_topics = total_topics - completed_topics

    # Quiz statistics
    cursor.execute("""
        SELECT COUNT(*) as attempts_count, AVG(score_percentage) as avg_score, MAX(score_percentage) as max_score
        FROM quiz_attempts WHERE learner_id = ?
    """, (learner_id,))
    quiz_stats = cursor.fetchone()
    attempts_count = quiz_stats["attempts_count"] or 0
    avg_score = round(quiz_stats["avg_score"], 1) if quiz_stats["avg_score"] is not None else 0.0
    max_score = round(quiz_stats["max_score"], 1) if quiz_stats["max_score"] is not None else 0.0

    progress_percentage = round((completed_topics / total_topics * 100), 1) if total_topics > 0 else 0.0

    conn.close()
    return {
        "active_plan_id": plan_id,
        "total_plans": total_plans,
        "total_topics": total_topics,
        "completed_topics": completed_topics,
        "pending_topics": pending_topics,
        "quizzes_attempted": attempts_count,
        "average_score": avg_score,
        "highest_score": max_score,
        "progress_percentage": progress_percentage
    }

# ----------------- Chat Operations ----------------- #

def save_chat_message(learner_id: int, role: str, message: str):
    """Saves a message in chat history."""
    conn = get_connection()
    with conn:
        conn.execute("INSERT INTO chat_history (learner_id, role, message) VALUES (?, ?, ?)", (learner_id, role, message))
    conn.close()

def get_chat_history(learner_id: int, limit: int = 50) -> List[Dict[str, Any]]:
    """Returns the chat history for a learner in chronological order."""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT role, message, created_at FROM (
            SELECT role, message, created_at FROM chat_history
            WHERE learner_id = ?
            ORDER BY id DESC LIMIT ?
        ) ORDER BY created_at ASC
    """, (learner_id, limit))
    rows = cursor.fetchall()
    conn.close()
    return [dict(r) for r in rows]

def clear_chat_history(learner_id: int):
    """Clears the chat history for a learner."""
    conn = get_connection()
    with conn:
        conn.execute("DELETE FROM chat_history WHERE learner_id = ?", (learner_id,))
    conn.close()

# Initialize on import
init_db()
