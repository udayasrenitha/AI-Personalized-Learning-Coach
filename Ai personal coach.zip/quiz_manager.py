"""
Quiz Manager for AI Personalized Learning Coach.
Handles quiz generation, Python-based evaluation, scoring, attempt persistence,
and review state.
"""

from typing import Dict, Any, List, Tuple, Optional
import database
import ai_service
import performance_analyzer

def fetch_or_generate_quiz(
    topic: Dict[str, Any],
    learner: Dict[str, Any]
) -> List[Dict[str, Any]]:
    """
    Generates a 5-question multiple choice quiz for the given topic.
    """
    topic_name = topic.get("topic_name", "General Concepts")
    subject = learner.get("subject", "General")
    level = learner.get("knowledge_level", "Beginner")
    style = learner.get("learning_style", "Practice")

    questions = ai_service.generate_quiz_ai(
        topic_name=topic_name,
        subject=subject,
        knowledge_level=level,
        learning_style=style
    )
    return questions

def evaluate_quiz_answers(
    questions: List[Dict[str, Any]],
    user_answers: Dict[int, str]
) -> Dict[str, Any]:
    """
    Calculates quiz score strictly using Python and the answer key.
    Never relies on the LLM to score.
    Returns structured results including score, percentage, and evaluated questions.
    """
    total_questions = len(questions)
    correct_count = 0
    evaluated_questions = []

    for idx, q in enumerate(questions):
        correct_opt = str(q.get("correct_option", "")).strip().upper()
        user_opt = str(user_answers.get(idx, "")).strip().upper()
        is_correct = (user_opt != "" and user_opt == correct_opt)

        if is_correct:
            correct_count += 1

        eval_q = dict(q)
        eval_q["user_selected_option"] = user_opt
        eval_q["is_correct"] = is_correct
        evaluated_questions.append(eval_q)

    score_percentage = round((correct_count / total_questions * 100), 1) if total_questions > 0 else 0.0

    return {
        "total_questions": total_questions,
        "correct_answers": correct_count,
        "incorrect_answers": total_questions - correct_count,
        "score_percentage": score_percentage,
        "evaluated_questions": evaluated_questions
    }

def record_quiz_submission(
    learner: Dict[str, Any],
    topic: Dict[str, Any],
    plan_id: int,
    evaluation_result: Dict[str, Any]
) -> Tuple[int, Dict[str, Any]]:
    """
    Saves the evaluated quiz attempt into SQLite, generates performance feedback,
    and updates learner progress.
    """
    score_percentage = evaluation_result["score_percentage"]
    topic_name = topic.get("topic_name", "Topic")
    subject = learner.get("subject", "General")
    level = learner.get("knowledge_level", "Beginner")

    # Generate adaptive recommendation
    rec = ai_service.generate_performance_recommendation(
        score_percentage=score_percentage,
        topic_name=topic_name,
        subject=subject,
        knowledge_level=level
    )

    attempt_id = database.save_quiz_attempt(
        learner_id=learner["id"],
        plan_id=plan_id,
        topic_id=topic["id"],
        topic_name=topic_name,
        total_questions=evaluation_result["total_questions"],
        correct_answers=evaluation_result["correct_answers"],
        score_percentage=score_percentage,
        status=rec["category"],
        recommendation=rec["summary"],
        questions_evaluated=evaluation_result["evaluated_questions"]
    )

    return attempt_id, rec

