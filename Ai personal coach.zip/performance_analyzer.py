"""
Performance Analyzer for AI Personalized Learning Coach.
Computes strengths, weaknesses, revision priorities, adaptive recommendations,
and next-action suggestions based on real SQLite data.
"""

from typing import Dict, Any, List, Optional
from config import THRESHOLDS
import database

def get_performance_tier(score_percentage: float) -> Dict[str, Any]:
    """
    Maps a quiz score percentage to its pedagogical tier and recommendation.
    Thresholds:
      - Below 40%: Fundamental revision & beginner practice
      - 40% - 69%: Additional examples & practice questions
      - 70% - 89%: Continued learning & moderate practice
      - 90% - 100%: Progress to next topic or advanced practice
    """
    if score_percentage < THRESHOLDS["fundamental_revision"]:
        return {
            "tier": "Needs Fundamental Revision",
            "badge_color": "danger",
            "color_hex": "#EF4444",
            "status": "Needs Revision",
            "action_type": "review_basics",
            "message": "Fundamental revision and beginner-level concept review recommended.",
            "guidance": "Focus on reviewing fundamental definitions and basic code syntax before re-attempting questions."
        }
    elif score_percentage < THRESHOLDS["practice_needed"]:
        return {
            "tier": "Practice & Examples Recommended",
            "badge_color": "warning",
            "color_hex": "#F59E0B",
            "status": "In Progress",
            "action_type": "more_practice",
            "message": "Additional examples and practice questions recommended to reinforce understanding.",
            "guidance": "Review the specific explanations of questions you missed and work through 2-3 code examples."
        }
    elif score_percentage < THRESHOLDS["good_progress"]:
        return {
            "tier": "Good Progress",
            "badge_color": "purple",
            "color_hex": "#7C3AED",
            "status": "Satisfactory",
            "action_type": "continue_learning",
            "message": "Strong grasp of core concepts. Continued learning and moderate practice recommended.",
            "guidance": "You have a solid foundation. Proceed to the next topic while keeping this topic fresh."
        }
    else:
        return {
            "tier": "Strong Performance",
            "badge_color": "success",
            "color_hex": "#10B981",
            "status": "Advanced Ready",
            "action_type": "advance_next",
            "message": "Excellent score! Ready to progress to the next topic or explore advanced challenge questions.",
            "guidance": "Outstanding result! Note that consistency across multiple sessions is needed to cement long-term mastery."
        }

def analyze_learner_performance(learner_id: int) -> Dict[str, Any]:
    """
    Aggregates all quiz attempts and progress to identify:
    - Overall average score
    - Strengths (topics with avg score >= 70%)
    - Weak topics (topics with avg score < 70% or flagged)
    - Topics attempted vs unattempted
    - Recommended next activity
    """
    attempts = database.get_quiz_attempts_for_learner(learner_id)
    summary = database.get_learner_progress_summary(learner_id)
    active_plan = database.get_active_study_plan(learner_id)

    topics_data = []
    if active_plan:
        topics_data = database.get_plan_topics(active_plan["id"])

    # Aggregate scores per topic
    topic_scores: Dict[str, List[float]] = {}
    for att in attempts:
        tname = att["topic_name"]
        if tname not in topic_scores:
            topic_scores[tname] = []
        topic_scores[tname].append(att["score_percentage"])

    strengths = []
    weaknesses = []

    for tname, scores in topic_scores.items():
        avg = sum(scores) / len(scores)
        topic_info = {
            "topic_name": tname,
            "average_score": round(avg, 1),
            "attempts_count": len(scores),
            "latest_score": scores[0]  # attempts are sorted desc
        }
        if avg >= THRESHOLDS["practice_needed"]:
            strengths.append(topic_info)
        else:
            weaknesses.append(topic_info)

    # Sort strengths descending, weaknesses ascending
    strengths.sort(key=lambda x: x["average_score"], reverse=True)
    weaknesses.sort(key=lambda x: x["average_score"])

    # Determine recommended next activity
    recommended_next = determine_next_recommended_activity(topics_data, weaknesses)

    return {
        "summary": summary,
        "total_attempts": len(attempts),
        "strengths": strengths,
        "weaknesses": weaknesses,
        "recommended_next": recommended_next,
        "recent_attempts": attempts[:5]
    }

def determine_next_recommended_activity(
    topics: List[Dict[str, Any]],
    weaknesses: List[Dict[str, Any]]
) -> Dict[str, Any]:
    """
    Recommends the best immediate next activity for the learner:
    1. If there are weak topics, prioritize revision for the lowest-scoring topic.
    2. Otherwise, recommend the first incomplete/unattempted topic.
    3. If all completed, recommend capstone or advanced practice.
    """
    # 1. Prioritize weak topic if any
    if weaknesses:
        weakest = weaknesses[0]
        # Match topic object
        matching = next((t for t in topics if t["topic_name"] == weakest["topic_name"]), None)
        return {
            "action": "Revise Weak Topic",
            "topic_id": matching["id"] if matching else None,
            "topic_name": weakest["topic_name"],
            "reason": f"Previous quiz average is {weakest['average_score']}%. Targeted revision will reinforce core concepts.",
            "badge_color": "warning",
            "button_text": f"Practice Quiz: {weakest['topic_name'][:25]}..."
        }

    # 2. Next uncompleted topic
    for t in topics:
        if not t.get("is_completed"):
            return {
                "action": "Continue Study Plan",
                "topic_id": t["id"],
                "topic_name": t["topic_name"],
                "reason": f"Day {t.get('day_number', 1)} is your next scheduled milestone.",
                "badge_color": "purple",
                "button_text": f"Start Day {t.get('day_number', 1)}: {t['topic_name'][:25]}..."
            }

    # 3. All completed
    if topics:
        return {
            "action": "All Topics Completed",
            "topic_id": topics[-1]["id"],
            "topic_name": "Capstone Review",
            "reason": "Congratulations on completing your study plan! Take comprehensive quizzes to cement long-term retention.",
            "badge_color": "success",
            "button_text": "Review Learning History"
        }

    return {
        "action": "Create Study Plan",
        "topic_id": None,
        "topic_name": "Profile Setup",
        "reason": "Create your personalized study plan to get started.",
        "badge_color": "purple",
        "button_text": "Go to Study Plan Setup"
    }

