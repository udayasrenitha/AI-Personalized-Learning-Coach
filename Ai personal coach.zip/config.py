"""
Configuration settings, upgraded modern CSS design system, and shared top navigation
for AI Personalized Learning Coach (sidebar removed).
"""

import os
import streamlit as st
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# App Information
APP_NAME = "AI Personalized Learning Coach"
APP_TAGLINE = "Your Intelligent Adaptive Study Companion"
APP_ICON = "🎓"
VERSION = "1.0.0"

# Design Palette (Light Lavender, Soft Purple, Deep Violet, Clean White)
THEME_COLORS = {
    "primary": "#7C3AED",          # Vibrant Soft Purple
    "primary_dark": "#6D28D9",     # Deep Purple
    "primary_light": "#DDD6FE",    # Light Lavender Accent
    "secondary": "#A78BFA",        # Soft Violet
    "background": "#F6F4FE",       # Ultra-soft Lavender Canvas
    "surface": "#FFFFFF",          # Pure White
    "surface_glass": "rgba(255, 255, 255, 0.88)",
    "surface_subtle": "#FAF8FF",   # Hint of purple/white
    "text_dark": "#181438",        # Deep Midnight Indigo
    "text_muted": "#5B647E",       # Soft Slate
    "border": "#E4DBFC",          # Border lavender
    "border_glow": "rgba(124, 58, 237, 0.25)",
    "success": "#10B981",          # Emerald Green
    "warning": "#F59E0B",          # Amber
    "danger": "#EF4444",           # Rose Red
    "info": "#3B82F6",             # Sky Blue
}

# Adaptive Performance Thresholds (Configurable)
THRESHOLDS = {
    "fundamental_revision": 40.0,   # Below 40%
    "practice_needed": 70.0,        # 40% - 69%
    "good_progress": 90.0,          # 70% - 89%
    "advanced_ready": 100.0         # 90% - 100%
}

def get_gemini_api_key() -> str:
    """
    Retrieve Gemini API key with priority:
    1. Streamlit session_state (user entered in UI)
    2. Environment variable GEMINI_API_KEY
    3. Environment variable GOOGLE_API_KEY
    """
    if "user_api_key" in st.session_state and st.session_state["user_api_key"]:
        return st.session_state["user_api_key"].strip()
    
    key = os.environ.get("GEMINI_API_KEY", "") or os.environ.get("GOOGLE_API_KEY", "")
    return key.strip()

def apply_custom_theme():
    """
    Inject upgraded modern CSS:
    - Sidebar completely hidden and removed
    - Glassmorphic soft lavender and clean purple aesthetic
    - Modern card elevations, smooth inputs, pill badges, and refined typography
    """
    custom_css = f"""
    <style>
    /* Google Fonts */
    @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500&display=swap');

    html, body, [class*="css"] {{
        font-family: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, sans-serif;
        color: {THEME_COLORS["text_dark"]};
    }}

    /* HIDE SIDEBAR COMPLETELY */
    [data-testid="stSidebar"], 
    section[data-testid="stSidebar"], 
    [data-testid="collapsedControl"],
    button[kind="header"] {{
        display: none !important;
    }}

    /* Expand main content container gracefully */
    .stApp {{
        background: radial-gradient(120% 80% at 50% 0%, #FAF8FF 0%, #F5F2FE 45%, #EFEBFC 100%);
        min-height: 100vh;
    }}

    section.main {{
        max-width: 100% !important;
        padding-top: 0.5rem !important;
    }}

    .block-container {{
        max-width: 1220px !important;
        padding: 1.2rem 2.2rem 4rem 2.2rem !important;
        margin: 0 auto !important;
    }}

    /* Top Navigation Bar */
    .top-navbar {{
        background: rgba(255, 255, 255, 0.95);
        backdrop-filter: blur(16px);
        -webkit-backdrop-filter: blur(16px);
        border: 1px solid rgba(228, 219, 252, 0.85);
        border-radius: 18px;
        padding: 14px 22px;
        margin-bottom: 24px;
        box-shadow: 0 10px 30px -10px rgba(109, 40, 217, 0.08), 0 2px 8px -2px rgba(0, 0, 0, 0.03);
    }}

    .nav-brand {{
        display: flex;
        align-items: center;
        gap: 12px;
        text-decoration: none;
    }}

    .nav-brand-icon {{
        background: linear-gradient(135deg, #7C3AED 0%, #6D28D9 100%);
        color: #FFFFFF;
        width: 38px;
        height: 38px;
        border-radius: 10px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 20px;
        box-shadow: 0 4px 12px rgba(124, 58, 237, 0.28);
    }}

    .nav-brand-title {{
        font-weight: 800;
        font-size: 1.15rem;
        color: #181438;
        letter-spacing: -0.02em;
        line-height: 1.1;
    }}

    .nav-brand-sub {{
        font-size: 0.72rem;
        color: #7C3AED;
        font-weight: 700;
        letter-spacing: 0.06em;
        text-transform: uppercase;
    }}

    /* Modern Glassmorphic Cards */
    .coach-card {{
        background: rgba(255, 255, 255, 0.92);
        backdrop-filter: blur(12px);
        -webkit-backdrop-filter: blur(12px);
        border-radius: 18px;
        padding: 24px 26px;
        border: 1px solid rgba(228, 219, 252, 0.85);
        box-shadow: 0 8px 30px -4px rgba(124, 58, 237, 0.06), 0 2px 8px -1px rgba(0, 0, 0, 0.02);
        margin-bottom: 22px;
        transition: transform 0.25s cubic-bezier(0.16, 1, 0.3, 1), box-shadow 0.25s cubic-bezier(0.16, 1, 0.3, 1), border-color 0.2s ease;
    }}

    .coach-card:hover {{
        transform: translateY(-2px);
        border-color: rgba(196, 181, 253, 0.95);
        box-shadow: 0 16px 40px -8px rgba(124, 58, 237, 0.12), 0 4px 12px -2px rgba(0, 0, 0, 0.04);
    }}

    /* Hero Banner */
    .hero-banner {{
        background: linear-gradient(135deg, #7C3AED 0%, #6D28D9 45%, #4C1D95 100%);
        border-radius: 22px;
        padding: 38px 36px;
        color: #FFFFFF;
        margin-bottom: 28px;
        box-shadow: 0 16px 36px -8px rgba(109, 40, 217, 0.38), 0 4px 12px rgba(0,0,0,0.06);
        position: relative;
        overflow: hidden;
    }}

    .hero-banner::after {{
        content: "";
        position: absolute;
        top: -60px;
        right: -60px;
        width: 240px;
        height: 240px;
        background: radial-gradient(circle, rgba(221, 214, 254, 0.25) 0%, rgba(255, 255, 255, 0) 70%);
        border-radius: 50%;
        pointer-events: none;
    }}

    .hero-banner h1 {{
        color: #FFFFFF !important;
        font-weight: 800;
        letter-spacing: -0.03em;
        margin-bottom: 10px;
    }}

    .hero-banner p {{
        color: #EDE9FE;
        font-size: 1.1rem;
        line-height: 1.6;
        max-width: 720px;
    }}

    /* Badges */
    .badge {{
        display: inline-flex;
        align-items: center;
        gap: 4px;
        padding: 5px 14px;
        border-radius: 9999px;
        font-size: 0.74rem;
        font-weight: 700;
        letter-spacing: 0.04em;
        text-transform: uppercase;
    }}

    .badge-purple {{
        background: #EDE9FE;
        color: #6D28D9;
        border: 1px solid #DDD6FE;
    }}

    .badge-success {{
        background: #D1FAE5;
        color: #065F46;
        border: 1px solid #A7F3D0;
    }}

    .badge-warning {{
        background: #FEF3C7;
        color: #92400E;
        border: 1px solid #FDE68A;
    }}

    .badge-danger {{
        background: #FEE2E2;
        color: #991B1B;
        border: 1px solid #FECACA;
    }}

    /* Stat Cards */
    .stat-card {{
        background: #FFFFFF;
        border-radius: 16px;
        padding: 20px 16px;
        border: 1px solid #E4DBFC;
        box-shadow: 0 4px 16px rgba(124, 58, 237, 0.05);
        text-align: center;
        transition: transform 0.2s ease, box-shadow 0.2s ease;
    }}

    .stat-card:hover {{
        transform: translateY(-2px);
        box-shadow: 0 8px 24px rgba(124, 58, 237, 0.1);
    }}

    .stat-value {{
        font-size: 2rem;
        font-weight: 800;
        color: #6D28D9;
        line-height: 1.1;
        letter-spacing: -0.02em;
    }}

    .stat-label {{
        font-size: 0.78rem;
        color: #5B647E;
        text-transform: uppercase;
        letter-spacing: 0.06em;
        margin-top: 6px;
        font-weight: 700;
    }}

    /* Modern Buttons */
    .stButton>button {{
        border-radius: 12px;
        font-weight: 700;
        font-size: 0.92rem;
        padding: 0.55rem 1.25rem;
        transition: all 0.25s cubic-bezier(0.16, 1, 0.3, 1);
        border: 1px solid #DDD6FE;
        background: #FFFFFF;
        color: #6D28D9;
        box-shadow: 0 2px 6px rgba(124, 58, 237, 0.06);
    }}

    .stButton>button:hover {{
        transform: translateY(-2px);
        border-color: #7C3AED;
        color: #5B21B6;
        box-shadow: 0 8px 20px rgba(124, 58, 237, 0.18);
    }}

    .stButton>button[kind="primary"] {{
        background: linear-gradient(135deg, #7C3AED 0%, #6D28D9 100%) !important;
        color: #FFFFFF !important;
        border: none !important;
        box-shadow: 0 4px 16px rgba(109, 40, 217, 0.32) !important;
    }}

    .stButton>button[kind="primary"]:hover {{
        background: linear-gradient(135deg, #6D28D9 0%, #5B21B6 100%) !important;
        transform: translateY(-2px) scale(1.008);
        box-shadow: 0 8px 24px rgba(109, 40, 217, 0.42) !important;
    }}

    /* Form Fields & Select Boxes */
    .stTextInput>div>div>input, 
    .stSelectbox>div>div, 
    .stNumberInput>div>div>input,
    .stTextArea>div>div>textarea {{
        border-radius: 12px !important;
        border: 1px solid #D8CCF8 !important;
        background: #FFFFFF !important;
        font-size: 0.95rem !important;
        box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.02) !important;
    }}

    .stTextInput>div>div>input:focus, 
    .stSelectbox>div>div:focus,
    .stNumberInput>div>div>input:focus,
    .stTextArea>div>div>textarea:focus {{
        border-color: #7C3AED !important;
        box-shadow: 0 0 0 3px rgba(124, 58, 237, 0.18) !important;
    }}

    /* Code & Pre */
    code {{
        background: #F3EEFF !important;
        color: #6D28D9 !important;
        padding: 2px 6px !important;
        border-radius: 6px !important;
        font-family: 'JetBrains Mono', monospace !important;
        font-size: 0.88em !important;
    }}

    /* Custom Scrollbar */
    ::-webkit-scrollbar {{
        width: 8px;
        height: 8px;
    }}
    ::-webkit-scrollbar-track {{
        background: #F5F2FE;
    }}
    ::-webkit-scrollbar-thumb {{
        background: #C4B5FD;
        border-radius: 9999px;
    }}
    ::-webkit-scrollbar-thumb:hover {{
        background: #A78BFA;
    }}
    </style>
    """
    st.markdown(custom_css, unsafe_allow_html=True)

def render_top_navigation(current_page: str = "home"):
    """
    Renders an elegant, modern top navigation bar in place of the removed sidebar.
    Includes brand logo, quick page links, active learner indicator, and API key modal.
    """
    import database

    active_learner = database.get_active_learner()
    all_learners = database.get_all_learners()
    api_key = get_gemini_api_key()

    # Top Brand and Navigation Bar
    st.markdown(
        f"""
        <div class="top-navbar">
            <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 14px;">
                <div class="nav-brand">
                    <div class="nav-brand-icon">{APP_ICON}</div>
                    <div>
                        <div class="nav-brand-title">AI Personalized Learning Coach</div>
                        <div class="nav-brand-sub">Adaptive Educational System &bull; Gemini 2.5</div>
                    </div>
                </div>
                <div style="display: flex; align-items: center; gap: 10px;">
                    <span class="badge {'badge-success' if api_key else 'badge-warning'}">
                        {'🟢 Gemini AI Connected' if api_key else '🟡 Offline / Demo Mode'}
                    </span>
                    {f"<span class='badge badge-purple'>👤 {active_learner['name']} ({active_learner['subject']})</span>" if active_learner else "<span class='badge' style='background:#F1F5F9; color:#475569;'>No Learner Selected</span>"}
                </div>
            </div>
        </div>
        """,
        unsafe_allow_html=True
    )

    # Clean Nav Buttons Row
    nav_cols = st.columns(7)
    
    pages_map = [
        ("🏠 Home", "home", "app.py"),
        ("👤 Profile", "profile", "pages/1_Learning_Profile.py"),
        ("📖 Study Plan", "plan", "pages/2_Study_Plan.py"),
        ("🎯 Practice Quiz", "quiz", "pages/3_Practice_Quiz.py"),
        ("🤖 AI Tutor", "assistant", "pages/4_AI_Assistant.py"),
        ("📊 Dashboard", "dashboard", "pages/5_Progress_Dashboard.py"),
        ("📜 History", "history", "pages/6_Learning_History.py"),
    ]

    for col, (label, page_id, file_path) in zip(nav_cols, pages_map):
        with col:
            is_active = (current_page == page_id)
            btn_type = "primary" if is_active else "secondary"
            if st.button(label, key=f"topnav_{page_id}", use_container_width=True, type=btn_type):
                if not is_active:
                    st.switch_page(file_path)

    # Learner & API Key management utilities (collapsible row)
    with st.expander("⚙️ Student Profile & Gemini API Key Settings", expanded=False):
        c_set1, c_set2 = st.columns([1, 1])
        
        with c_set1:
            st.markdown("##### 👤 Switch Active Learner Profile")
            if all_learners:
                learner_options = {l["id"]: f"{l['name']} — {l['subject']} ({l['knowledge_level']})" for l in all_learners}
                current_id = active_learner["id"] if active_learner else all_learners[0]["id"]
                if current_id not in learner_options:
                    current_id = all_learners[0]["id"]

                selected_id = st.selectbox(
                    "Active Profile",
                    options=list(learner_options.keys()),
                    format_func=lambda x: learner_options[x],
                    index=list(learner_options.keys()).index(current_id),
                    key="top_learner_select",
                    label_visibility="collapsed"
                )
                if active_learner is None or selected_id != active_learner["id"]:
                    database.set_active_learner_id(selected_id)
                    st.rerun()
            else:
                st.caption("No learner profiles found. Create one in **Profile**.")

        with c_set2:
            st.markdown("##### 🔑 Google Gemini API Key")
            new_key = st.text_input(
                "Gemini API Key",
                type="password",
                value=st.session_state.get("user_api_key", ""),
                placeholder="AIzaSy... (leave blank for offline demo mode)",
                label_visibility="collapsed"
            )
            c_save1, c_save2 = st.columns([1, 1])
            with c_save1:
                if st.button("Save API Key", key="save_api_key_btn", use_container_width=True):
                    if new_key:
                        st.session_state["user_api_key"] = new_key.strip()
                        st.success("API key saved!")
                        st.rerun()
                    else:
                        st.session_state.pop("user_api_key", None)
                        st.rerun()
            with c_save2:
                st.caption("Free key from: [Google AI Studio](https://aistudio.google.com/app/apikey)")

    st.markdown("<div style='margin-bottom: 22px;'></div>", unsafe_allow_html=True)
