"""
Learning Assistant Service for AI Personalized Learning Coach.
Manages context assembly, conversation memory, prompt suggestions, and Gemini chat interaction.
"""

from typing import Dict, Any, List
import database
import ai_service

QUICK_PROMPTS = [
    "💡 Explain this concept using a simple real-world analogy",
    "💻 Show a practical code example with step-by-step line explanations",
    "🐛 What are common beginner pitfalls and how do I avoid them?",
    "📝 Summarize key takeaways for quick revision",
    "🎯 Give me a 15-minute hands-on coding challenge with hints"
]

def get_learner_context_dict(learner_id: int) -> Dict[str, Any]:
    """
    Assembles real student context from SQLite:
    - Learner profile (subject, level, goal, style)
    - Active topic
    - Weak topics needing revision
    """
    learner = database.get_learner_by_id(learner_id)
    if not learner:
        return {}

    active_plan = database.get_active_study_plan(learner_id)
    current_topic_name = "General Subject Fundamentals"

    if active_plan:
        topics = database.get_plan_topics(active_plan["id"])
        # Find first incomplete topic
        incomplete = next((t for t in topics if not t.get("is_completed")), None)
        if incomplete:
            current_topic_name = incomplete["topic_name"]
        elif topics:
            current_topic_name = topics[-1]["topic_name"]

    weak_topics_data = database.get_weak_topics(learner_id)
    weak_names = [w["topic_name"] for w in weak_topics_data]

    return {
        "learner_id": learner_id,
        "name": learner["name"],
        "subject": learner["subject"],
        "goal": learner["goal"],
        "knowledge_level": learner["knowledge_level"],
        "learning_style": learner["learning_style"],
        "daily_minutes": learner["daily_minutes"],
        "current_topic": current_topic_name,
        "weak_topics": weak_names
    }

def process_user_chat_message(learner_id: int, user_message: str) -> str:
    """
    Saves user message, fetches history and learner context, calls Gemini AI,
    saves the AI response, and returns it.
    """
    # 1. Save user message to database
    database.save_chat_message(learner_id, "user", user_message)

    # 2. Get history and learner context
    history = database.get_chat_history(learner_id, limit=20)
    context = get_learner_context_dict(learner_id)

    # 3. Call AI assistant
    assistant_response = ai_service.ask_learning_assistant(
        message=user_message,
        chat_history=history,
        learner_context=context
    )

    # 4. Save AI response to database
    database.save_chat_message(learner_id, "assistant", assistant_response)

    return assistant_response

