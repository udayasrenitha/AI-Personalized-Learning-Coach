"""
Comprehensive Automated Test Suite for AI Personalized Learning Coach.
Tests all requirements from Section 9 & Section 12:
- Valid learner registration
- Input validation (missing subject, invalid days, invalid minutes)
- Study plan generation & regeneration
- Topic retrieval & progress tracking
- 5-question quiz generation
- Python answer key scoring (exact evaluation, no LLM math)
- Performance tier mapping (<40%, 40-69%, 70-89%, 90-100%)
- Weak-topic identification
- Dashboard aggregations
- SQLite persistence across sessions
"""

import unittest
import os
import database
import ai_service
import learning_plan
import quiz_manager
import performance_analyzer
from config import THRESHOLDS

class TestAILearningCoach(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        database.init_db()

    def test_01_learner_validation(self):
        """Test input validation for learner setup."""
        # Missing subject
        valid, err = learning_plan.validate_plan_inputs("", "Learn loops", "Beginner", 7, 45, "Mixed")
        self.assertFalse(valid)
        self.assertIn("subject", err.lower())

        # Missing goal
        valid, err = learning_plan.validate_plan_inputs("Python", "", "Beginner", 7, 45, "Mixed")
        self.assertFalse(valid)
        self.assertIn("goal", err.lower())

        # Invalid days (< 1)
        valid, err = learning_plan.validate_plan_inputs("Python", "Learn basics", "Beginner", 0, 45, "Mixed")
        self.assertFalse(valid)

        # Invalid minutes (< 10)
        valid, err = learning_plan.validate_plan_inputs("Python", "Learn basics", "Beginner", 7, 5, "Mixed")
        self.assertFalse(valid)

        # Valid setup
        valid, err = learning_plan.validate_plan_inputs("Python", "Learn basics from scratch", "Beginner", 7, 45, "Mixed")
        self.assertTrue(valid)
        self.assertIsNone(err)

    def test_02_learner_crud_and_persistence(self):
        """Test creating and retrieving learners in SQLite."""
        lid = database.save_learner(
            name="Test Student",
            subject="FastAPI",
            goal="Build production REST APIs",
            knowledge_level="Intermediate",
            target_days=10,
            daily_minutes=60,
            learning_style="Practice"
        )
        self.assertIsNotNone(lid)

        learner = database.get_learner_by_id(lid)
        self.assertEqual(learner["name"], "Test Student")
        self.assertEqual(learner["subject"], "FastAPI")
        self.assertEqual(learner["knowledge_level"], "Intermediate")
        self.assertEqual(learner["target_days"], 10)

    def test_03_study_plan_generation_and_persistence(self):
        """Test structured study plan generation and storage."""
        learner = database.get_active_learner()
        self.assertIsNotNone(learner)

        success, plan_id = learning_plan.create_and_save_study_plan(
            learner_id=learner["id"],
            subject=learner["subject"],
            goal=learner["goal"],
            knowledge_level=learner["knowledge_level"],
            target_days=learner["target_days"],
            daily_minutes=learner["daily_minutes"],
            learning_style=learner["learning_style"]
        )
        self.assertTrue(success)
        self.assertIsInstance(plan_id, int)

        # Verify topics
        topics = database.get_plan_topics(plan_id)
        self.assertEqual(len(topics), learner["target_days"])
        for t in topics:
            self.assertIn("topic_name", t)
            self.assertIn("objectives", t)
            self.assertIn("key_concepts", t)
            self.assertIn("practical_activities", t)
            self.assertIn("revision_tasks", t)

    def test_04_topic_completion_toggle(self):
        """Test marking topics completed updates progress."""
        learner = database.get_active_learner()
        plan = database.get_active_study_plan(learner["id"])
        topics = database.get_plan_topics(plan["id"])
        topic = topics[0]

        # Toggle to completed
        database.toggle_topic_completion(topic["id"], True)
        updated_topic = database.get_topic_by_id(topic["id"])
        self.assertEqual(updated_topic["is_completed"], 1)

        # Toggle back to pending
        database.toggle_topic_completion(topic["id"], False)
        updated_topic2 = database.get_topic_by_id(topic["id"])
        self.assertEqual(updated_topic2["is_completed"], 0)

    def test_05_quiz_generation_schema(self):
        """Test that generated quizzes strictly contain 5 MCQs with valid schema."""
        questions = ai_service.generate_fallback_quiz("Functions", "Python", "Beginner")
        self.assertEqual(len(questions), 5)
        for q in questions:
            self.assertIn("question", q)
            self.assertIn("options", q)
            self.assertIn("correct_option", q)
            self.assertIn("explanation", q)
            self.assertIn("difficulty", q)
            self.assertIn(q["correct_option"], ["A", "B", "C", "D"])
            self.assertEqual(len(q["options"]), 4)

    def test_06_python_score_calculation(self):
        """Test that quiz scoring is calculated strictly by Python answer key."""
        questions = [
            {"question": "Q1", "correct_option": "A", "options": {"A": "1", "B": "2", "C": "3", "D": "4"}},
            {"question": "Q2", "correct_option": "B", "options": {"A": "1", "B": "2", "C": "3", "D": "4"}},
            {"question": "Q3", "correct_option": "C", "options": {"A": "1", "B": "2", "C": "3", "D": "4"}},
            {"question": "Q4", "correct_option": "D", "options": {"A": "1", "B": "2", "C": "3", "D": "4"}},
            {"question": "Q5", "correct_option": "A", "options": {"A": "1", "B": "2", "C": "3", "D": "4"}}
        ]

        # Scenario: 5 out of 5 correct (100%)
        res_full = quiz_manager.evaluate_quiz_answers(questions, {0: "A", 1: "B", 2: "C", 3: "D", 4: "A"})
        self.assertEqual(res_full["correct_answers"], 5)
        self.assertEqual(res_full["score_percentage"], 100.0)

        # Scenario: 2 out of 5 correct (40%)
        res_low = quiz_manager.evaluate_quiz_answers(questions, {0: "A", 1: "B", 2: "A", 3: "A", 4: "B"})
        self.assertEqual(res_low["correct_answers"], 2)
        self.assertEqual(res_low["incorrect_answers"], 3)
        self.assertEqual(res_low["score_percentage"], 40.0)

        # Scenario: Case insensitivity
        res_case = quiz_manager.evaluate_quiz_answers(questions, {0: "a", 1: "b", 2: "c", 3: "d", 4: "a"})
        self.assertEqual(res_case["correct_answers"], 5)

    def test_07_adaptive_recommendation_tiers(self):
        """Test performance tier mapping and adaptive actions."""
        # Tier 1: Below 40% (Needs Fundamental Revision)
        tier_low = performance_analyzer.get_performance_tier(20.0)
        self.assertEqual(tier_low["badge_color"], "danger")
        self.assertIn("Fundamental revision", tier_low["message"])

        # Tier 2: 40% - 69% (Practice Recommended)
        tier_mid = performance_analyzer.get_performance_tier(60.0)
        self.assertEqual(tier_mid["badge_color"], "warning")
        self.assertIn("Additional examples", tier_mid["message"])

        # Tier 3: 70% - 89% (Good Progress)
        tier_good = performance_analyzer.get_performance_tier(80.0)
        self.assertEqual(tier_good["badge_color"], "purple")
        self.assertIn("Continued learning", tier_good["message"])

        # Tier 4: 90% - 100% (Strong Performance)
        tier_top = performance_analyzer.get_performance_tier(100.0)
        self.assertEqual(tier_top["badge_color"], "success")
        self.assertIn("advance", tier_top["message"].lower())

    def test_08_weak_topic_identification(self):
        """Test that topics scoring < 70% are automatically flagged for revision."""
        # Find learner Alex Johnson who has the seeded quiz attempts
        learners = database.get_all_learners()
        alex = next((l for l in learners if l["name"] == "Alex Johnson"), None)
        self.assertIsNotNone(alex, "Alex Johnson should exist from seed")
        
        weak_topics = database.get_weak_topics(alex["id"], threshold=70.0)
        topic_names = [w["topic_name"] for w in weak_topics]
        self.assertTrue(any("loop" in name.lower() for name in topic_names), f"Expected 'loops' in weak topics: {topic_names}")

    def test_09_dashboard_metrics_aggregation(self):
        """Test that dashboard progress summary calculates accurately from SQLite."""
        learners = database.get_all_learners()
        alex = next((l for l in learners if l["name"] == "Alex Johnson"), None)
        self.assertIsNotNone(alex)
        
        summary = database.get_learner_progress_summary(alex["id"])
        self.assertGreater(summary["total_plans"], 0)
        self.assertGreater(summary["total_topics"], 0)
        self.assertGreaterEqual(summary["completed_topics"], 1)
        self.assertGreaterEqual(summary["quizzes_attempted"], 1)
        self.assertIsInstance(summary["average_score"], float)
        self.assertIsInstance(summary["progress_percentage"], float)

    def test_10_chat_history_persistence(self):
        """Test saving and retrieving student-coach chat history."""
        learner = database.get_active_learner()
        database.save_chat_message(learner["id"], "user", "What is an iterator?")
        database.save_chat_message(learner["id"], "assistant", "An iterator is an object that contains a countable number of values.")

        history = database.get_chat_history(learner["id"], limit=10)
        self.assertGreaterEqual(len(history), 2)
        last_user = next((m for m in reversed(history) if m["role"] == "user"), None)
        self.assertEqual(last_user["message"], "What is an iterator?")

if __name__ == "__main__":
    unittest.main()
